package leo.lei.note

import org.json.JSONArray
import org.json.JSONObject

/** Owns persisted rich-text commands so the Activity only coordinates UI behavior. */
internal class EditorFormattingState {
    val colors = mutableListOf<JSONObject>()
    val styles = mutableListOf<JSONObject>()
    val fonts = mutableListOf<JSONObject>()

    fun load(post: JSONObject?) {
        colors.clear(); styles.clear(); fonts.clear()
        copy(post?.optJSONArray("colorCommands"), colors)
        copy(post?.optJSONArray("styleCommands"), styles)
        copy(post?.optJSONArray("fontCommands"), fonts)
    }

    fun writeTo(post: JSONObject) {
        post.put("colorCommands", asArray(colors))
        post.put("styleCommands", asArray(styles))
        post.put("fontCommands", asArray(fonts))
    }

    private fun copy(source: JSONArray?, target: MutableList<JSONObject>) {
        if (source == null) return
        for (i in 0 until source.length()) source.optJSONObject(i)?.let { target += JSONObject(it.toString()) }
    }

    private fun asArray(source: List<JSONObject>) = JSONArray().apply {
        source.forEach { put(JSONObject(it.toString())) }
    }
}
