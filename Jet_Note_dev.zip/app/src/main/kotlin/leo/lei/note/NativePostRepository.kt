package leo.lei.note

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

internal class NativePostRepository(context: Context) {
    private val preferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    fun hasNativeData(): Boolean = preferences.contains(POSTS_KEY)

    fun allModels(): MutableList<Post> = runCatching {
        val stored = JSONArray(preferences.getString(POSTS_KEY, "[]"))
        MutableList(stored.length()) { PostCodec.decode(stored.getJSONObject(it)) }
    }.getOrElse { mutableListOf() }

    // Compatibility boundary for UI/backup code that has not migrated yet.
    fun all(): MutableList<JSONObject> = allModels().mapTo(mutableListOf(), PostCodec::encode)

    fun replaceModels(posts: List<Post>) {
        val serialized = JSONArray().apply { posts.forEach { put(PostCodec.encode(it)) } }.toString()
        preferences.edit().putString(POSTS_KEY, serialized).apply()
    }

    fun replace(posts: List<JSONObject>) = replaceModels(posts.map(PostCodec::decode))

    fun upsert(source: JSONObject): JSONObject {
        val posts = allModels()
        val incoming = PostCodec.decode(source)
        val timestamp = Instant.now().toString()
        val postId = incoming.id.ifBlank { System.currentTimeMillis().toString() }
        val normalized = incoming.copy(
            id = postId,
            uuid = incoming.uuid.ifBlank { NoteIdentity.create() },
            createdAt = incoming.createdAt ?: timestamp,
            updatedAt = timestamp
        )
        val index = posts.indexOfFirst { it.id == postId }
        if (index >= 0) posts[index] = normalized else posts.add(normalized)
        replaceModels(posts)
        return PostCodec.encode(normalized)
    }

    fun delete(postId: String) = replaceModels(allModels().filterNot { it.id == postId })

    fun setArchived(postId: String, archived: Boolean) = mutate { posts ->
        val index = posts.indexOfFirst { it.id == postId }
        if (index >= 0) posts[index] = PostRules.setArchived(posts[index], archived)
    }

    fun toggleStar(postId: String, superStar: Boolean = false) = mutate { posts ->
        PostRules.changeStar(posts, postId, if (superStar) StarState.SUPER_STAR else null, Instant.now().toString())
    }

    private inline fun mutate(change: (MutableList<Post>) -> Unit) {
        val posts = allModels(); change(posts); replaceModels(posts)
    }

    private companion object {
        const val PREFERENCES_NAME = "jet_note_native_posts"
        const val POSTS_KEY = "posts_json_v1"
    }
}
