package leo.lei.note

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import java.io.File

class NativeImageViewerActivity : Activity() {
    private lateinit var image: ImageView
    private lateinit var transitionTopBar: View
    private var closing = false
    private var scale = 1f
    private var tx = 0f; private var ty = 0f
    private var lastX = 0f; private var lastY = 0f
    private var backgroundIndex = 0
    private val backgrounds = intArrayOf(Color.BLACK, Color.WHITE, Color.GRAY)
    private val density get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * density + .5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val file = intent.getStringExtra(EXTRA_FILE_PATH)?.let(::File) ?: run { finish(); return }
        if (!file.isFile) { finish(); return }
        window.statusBarColor = Color.TRANSPARENT; window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) { window.isStatusBarContrastEnforced = false; window.isNavigationBarContrastEnforced = false }
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        val root = FrameLayout(this).apply { setBackgroundColor(backgrounds[0]) }
        image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            val dm = resources.displayMetrics
            setImageBitmap(BitmapLoader.decode(file, dm.widthPixels * 2, dm.heightPixels * 2))
        }
        root.addView(image, FrameLayout.LayoutParams(-1, -1))
        val detector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { scale = (scale * d.scaleFactor).coerceIn(1f, 8f); if (scale <= 1.01f) { tx=0f; ty=0f }; applyTransform(); return true }
        })
        root.setOnTouchListener { _, e ->
            detector.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lastX=e.x; lastY=e.y }
                MotionEvent.ACTION_MOVE -> if (!detector.isInProgress && scale > 1.01f) { tx += e.x-lastX; ty += e.y-lastY; lastX=e.x; lastY=e.y; applyTransform() }
                MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_UP -> { lastX=e.x; lastY=e.y }
            }; true
        }
        val bar = NativeTopBar.build(
            this,
            if (UiLanguage.languageCode(this) == "zh") "图片查看器" else "Image Viewer",
            leftRes = R.drawable.jet_editor_close,
            rightRes = null,
            onLeft = { finishWithReverseAnimation() }
        )
        root.addView(bar, FrameLayout.LayoutParams(-1, dp(NativeTopBar.HEIGHT_DP), Gravity.TOP))
        transitionTopBar = bar
        val bgButton = textButton("◐") { backgroundIndex=(backgroundIndex+1)%backgrounds.size; root.setBackgroundColor(backgrounds[backgroundIndex]) }
        val dlButton = textButton("↓") { MediaFileManager.downloadFile(this, file, null, "image") }
        bar.addView(bgButton, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin=dp(66) })
        bar.addView(dlButton, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin=dp(14) })
        SystemInsets.listen(bar) { safe ->
            bar.setPadding(0, safe.top, 0, 0)
            bar.layoutParams = (bar.layoutParams as FrameLayout.LayoutParams).apply { height = safe.top + dp(NativeTopBar.HEIGHT_DP) }
        }
        setContentView(root)
        
    }

    override fun onDestroy() {
        if (::image.isInitialized) {
            image.setImageDrawable(null)
        }
        super.onDestroy()
    }

    private fun finishWithReverseAnimation() {
        if (closing) return
        if (!::transitionTopBar.isInitialized || !::image.isInitialized) { PageActivityTransition.finish(this); return }
        closing = true
        PageActivityTransition.finish(this)
    }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = finishWithReverseAnimation()

    private fun textButton(label: String, action: () -> Unit) = TextView(this).apply { text=label; textSize=28f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); setOnClickListener { action() } }
    private fun applyTransform() { image.scaleX=scale; image.scaleY=scale; image.translationX=tx; image.translationY=ty }
    companion object { const val EXTRA_FILE_PATH = "jetnote.image.file" }
}
