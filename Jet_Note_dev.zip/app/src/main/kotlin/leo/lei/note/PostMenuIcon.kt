package leo.lei.note

internal object PostMenuIcon {
    fun html(): String =
        "<img src=\"src/shared/icons/more_horizontal.svg\" alt=\"\" aria-hidden=\"true\">"
}
