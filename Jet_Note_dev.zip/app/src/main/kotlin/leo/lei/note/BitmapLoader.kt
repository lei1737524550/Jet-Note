package leo.lei.note

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

/** Decodes images near their display size instead of retaining full-resolution bitmaps in RAM. */
internal object BitmapLoader {
    fun decode(file: File, reqWidth: Int, reqHeight: Int): Bitmap? {
        if (!file.isFile) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        val targetW = reqWidth.coerceAtLeast(1)
        val targetH = reqHeight.coerceAtLeast(1)
        while (bounds.outWidth / (sample * 2) >= targetW && bounds.outHeight / (sample * 2) >= targetH) {
            sample *= 2
        }
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        })
    }
}
