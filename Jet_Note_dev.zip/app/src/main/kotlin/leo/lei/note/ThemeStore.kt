package leo.lei.note

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.app.Activity
import android.os.Build
import android.view.View
import org.json.JSONObject

object ThemeStore {
    private const val PREFS = "jet_note_theme"
    private const val KEY_MODE = "mode"
    private const val KEY_CUSTOM = "custom_theme"

    enum class Mode(val id: String) { SYSTEM("system"), CUSTOM("custom") }

    enum class Theme(val id: String, val top: String, val body: String) {
        GREEN("green", "#AED194", "#D2E9C2"),
        DARK("dark", "#38393E", "#121318"),
        LIGHT("light", "#EEEDF4", "#FAF8FF");

        val topColor: Int get() = Color.parseColor(top)
        val bodyColor: Int get() = Color.parseColor(body)
        val foregroundColor: Int get() = if (this == DARK) Color.WHITE else Color.rgb(17, 18, 20)
    }

    fun mode(context: Context): Mode {
        val id = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_MODE, Mode.SYSTEM.id)
        return Mode.entries.firstOrNull { it.id == id } ?: Mode.SYSTEM
    }

    fun custom(context: Context): Theme {
        val id = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_CUSTOM, Theme.GREEN.id)
        return Theme.entries.firstOrNull { it.id == id } ?: Theme.GREEN
    }

    fun systemTheme(context: Context): Theme {
        val night = context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return if (night == Configuration.UI_MODE_NIGHT_YES) Theme.DARK else Theme.LIGHT
    }

    fun current(context: Context): Theme = if (mode(context) == Mode.SYSTEM) systemTheme(context) else custom(context)

    
    fun applyWindow(activity: Activity) {
        val theme = current(activity)
        activity.window.statusBarColor = theme.topColor
        activity.window.navigationBarColor = theme.bodyColor
        activity.window.decorView.setBackgroundColor(theme.bodyColor)
        @Suppress("DEPRECATION")
        var flags = activity.window.decorView.systemUiVisibility
        flags = if (theme == Theme.DARK) {
            flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        } else {
            flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        @Suppress("DEPRECATION")
        activity.window.decorView.systemUiVisibility = flags
    }

    fun setMode(context: Context, id: String): Boolean {
        val value = Mode.entries.firstOrNull { it.id == id } ?: return false
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_MODE, value.id).commit()
    }

    
    fun set(context: Context, id: String): Boolean {
        val theme = Theme.entries.firstOrNull { it.id == id } ?: return false
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_CUSTOM, theme.id).putString(KEY_MODE, Mode.CUSTOM.id).commit()
    }

    fun applyToConfig(context: Context, raw: String): String {
        val theme = current(context)
        val json = JSONObject(raw)
        json.put("global_set_background", theme.top)
        json.put("global_set_body", theme.body)
        json.optJSONObject("load_animation")?.put("load_animation_background", theme.top)
        return json.toString()
    }

    fun applyToSection(context: Context, section: String, raw: String): String {
        val theme = current(context)
        val json = JSONObject(raw)
        when (section.lowercase()) {
            "config.json", "config" -> {
                json.put("global_set_background", theme.top)
                json.put("global_set_body", theme.body)
            }
            "anim.json", "anim" -> json.optJSONObject("load_animation")?.put("load_animation_background", theme.top)
        }
        return json.toString()
    }
}
