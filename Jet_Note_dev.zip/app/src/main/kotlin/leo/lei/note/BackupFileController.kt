package leo.lei.note

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.time.Instant
import java.util.*
import java.util.concurrent.Executors
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

internal class BackupFileController(
    private val activity: Activity,
    private val repository: NativePostRepository,
    private val store: AttachmentStore,
    private val onChanged: () -> Unit
) {
    companion object {
        const val SAVE = 7311
        const val OPEN = 7312
        private const val FORMAT = "jet-note"
        private const val FORMAT_VERSION = 2
        private const val MAX_ENTRIES = 10_000
        private const val MAX_METADATA = 32L * 1024L * 1024L
        private const val MAX_ARCHIVE = 128L * 1024L * 1024L
    }

    private val io = Executors.newSingleThreadExecutor()
    private var pendingExport: JSONArray? = null

    fun exportArchive() {
        val posts = normalizedPosts(repository.all())
        pendingExport = posts
        val name = "JetNote_" + SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date()) + ".jnote"
        activity.startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.jnote+zip"
            putExtra(Intent.EXTRA_TITLE, name)
        }, SAVE)
    }

    fun chooseArchive() {
        activity.startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/vnd.jnote+zip", "application/zip", "application/octet-stream"))
        }, OPEN)
    }

    fun handles(requestCode: Int) = requestCode == SAVE || requestCode == OPEN

    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode != Activity.RESULT_OK || data?.data == null) {
            if (requestCode == SAVE) pendingExport = null
            return
        }
        val uri = data.data!!
        if (requestCode == SAVE) {
            val posts = pendingExport ?: return
            pendingExport = null
            io.execute { writeArchive(uri, posts) }
        } else io.execute { readArchive(uri) }
    }

    private fun writeArchive(uri: Uri, posts: JSONArray) {
        val temp = File(activity.cacheDir, "jnote-export-${UUID.randomUUID()}.jnote")
        try {
            validateAttachmentMetadata(posts) { store.fileForArchivePath(it) }
            val paths = collectMediaPaths(posts)
            val manifest = JSONObject()
                .put("format", FORMAT).put("formatVersion", FORMAT_VERSION)
                .put("app", "Jet Note").put("createdAt", isoNow()).put("encoding", "UTF-8")
                .put("content", JSONObject().put("posts", "data/posts.json"))
            val checksums = JSONObject()
            ZipOutputStream(BufferedOutputStream(FileOutputStream(temp))).use { zip ->
                putCheckedText(zip, "manifest.json", manifest.toString(2), checksums)
                putCheckedText(zip, "data/posts.json", posts.toString(2), checksums)
                for (path in paths) {
                    val file = store.fileForArchivePath(path) ?: throw IOException("Invalid media path: $path")
                    if (!file.isFile) throw IOException("Missing media: $path")
                    val hash = AttachmentStore.sha256(file)
                    zip.putNextEntry(ZipEntry(path)); FileInputStream(file).use { it.copyTo(zip, 128 * 1024) }; zip.closeEntry()
                    checksums.put(path, hash)
                }
                zip.putNextEntry(ZipEntry("checksums.json")); zip.write(checksums.toString(2).toByteArray(StandardCharsets.UTF_8)); zip.closeEntry()
            }
            verifyArchive(temp, paths)
            val sourceHash = AttachmentStore.sha256(temp)
            activity.contentResolver.openOutputStream(uri, "w")?.use { out -> FileInputStream(temp).use { it.copyTo(out, 128 * 1024) }; out.flush() }
                ?: throw IOException("Cannot open export destination")
            val written = File(activity.cacheDir, "jnote-export-verify-${UUID.randomUUID()}.jnote")
            try {
                activity.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(written).use { out -> copyLimited(input, out, MAX_ARCHIVE) } }
                    ?: throw IOException("Cannot read exported file back")
                if (!sourceHash.equals(AttachmentStore.sha256(written), true)) throw IOException("Final export file integrity mismatch")
                verifyArchive(written, paths)
            } finally { written.delete() }
            toast(if (isZh()) "导出完成，完整性校验通过" else "Export complete; integrity verified")
        } catch (e: Exception) {
            toast((if (isZh()) "导出失败：" else "Export failed: ") + (e.message ?: "unknown error"))
        } finally { temp.delete() }
    }

    private fun readArchive(uri: Uri) {
        var stage: File? = null
        try {
            val token = UUID.randomUUID().toString()
            stage = File(activity.cacheDir, "jnote-import-$token").apply { mkdirs() }
            val archive = File(stage, "source.jnote")
            activity.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(archive).use { out -> copyLimited(input, out, MAX_ARCHIVE) } }
                ?: throw IOException("Cannot open backup")
            val extracted = LinkedHashSet<String>(); var count = 0
            ZipInputStream(BufferedInputStream(FileInputStream(archive))).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (++count > MAX_ENTRIES) throw IOException("Too many archive entries")
                    val name = normalizeEntry(entry.name); validateEntry(name)
                    if (!entry.isDirectory) {
                        val out = safeFile(stage, name); out.parentFile?.mkdirs()
                        FileOutputStream(out).use { copyLimited(zip, it, MAX_ARCHIVE) }; extracted.add(name)
                    }
                    zip.closeEntry()
                }
            }
            val manifestFile = safeFile(stage, "manifest.json")
            val postsFile = safeFile(stage, "data/posts.json")
            val checksFile = safeFile(stage, "checksums.json")
            if (!manifestFile.isFile || !postsFile.isFile || !checksFile.isFile) throw IOException("Backup is missing required metadata")
            val manifest = JSONObject(readUtf8(manifestFile))
            if (manifest.optString("format") != FORMAT || manifest.optInt("formatVersion", -1) != FORMAT_VERSION) throw IOException("Unsupported Jet Note backup")
            if (manifest.optString("encoding") != "UTF-8" || manifest.optJSONObject("content")?.optString("posts") != "data/posts.json") throw IOException("Invalid content map")
            val posts = normalizedPosts(JSONArray(readUtf8(postsFile)))
            val checks = JSONObject(readUtf8(checksFile))
            for (key in checks.keys()) {
                validateEntry(key); if (key == "checksums.json") throw IOException("Invalid self checksum")
                val file = safeFile(stage, key)
                if (!file.isFile || !AttachmentStore.sha256(file).equals(checks.getString(key), true)) throw IOException("Checksum mismatch: $key")
            }
            for (req in listOf("manifest.json", "data/posts.json")) if (!checks.has(req)) throw IOException("Missing checksum: $req")
            val referenced = collectMediaPaths(posts)
            val actual = extracted.filter { it.startsWith("media/") }.toSet()
            if (actual != referenced) throw IOException("Media manifest does not match ZIP")
            for (path in referenced) if (!checks.has(path)) throw IOException("Unchecked media: $path")
            val readyStage: File = requireNotNull(stage)
            validateAttachmentMetadata(posts) { path -> safeFile(readyStage, path) }
            stage = null
            activity.runOnUiThread { showImportModeDialog(readyStage, posts, referenced) }
        } catch (e: Exception) {
            stage?.deleteRecursively()
            toast((if (isZh()) "导入失败：" else "Import failed: ") + (e.message ?: "unknown error"))
        }
    }

    private fun showImportModeDialog(stage: File, incoming: JSONArray, media: Set<String>) {
        val zh = isZh()
        val choices = if (zh) listOf(
            JetNoteDialog.Choice("添加", "仅加入不存在的笔记，保留当前内容"),
            JetNoteDialog.Choice("更新合并", "加入新笔记，并用较新的版本更新已有笔记"),
            JetNoteDialog.Choice("全部替换", "用备份完整替换当前笔记", destructive = true)
        ) else listOf(
            JetNoteDialog.Choice("Add", "Add missing posts and keep current content"),
            JetNoteDialog.Choice("Update / merge", "Add new posts and update existing posts when newer"),
            JetNoteDialog.Choice("Replace all", "Replace all current posts with this backup", destructive = true)
        )
        JetNoteDialog.showChoices(
            activity = activity,
            title = if (zh) "导入备份" else "Import backup",
            message = if (zh) "备份已通过完整性校验。请选择导入方式。" else "The backup passed integrity verification. Choose how to import it.",
            choices = choices,
            cancelText = if (zh) "取消" else "Cancel",
            onChoice = { which -> io.execute { commitImport(stage, incoming, media, which) } },
            onCancel = { stage.deleteRecursively() }
        )
    }

    private fun commitImport(stage: File, incoming: JSONArray, media: Set<String>, mode: Int) {
        val installed = mutableListOf<File>()
        try {
            for (path in media) {
                val from = safeFile(stage, path)
                val to = store.fileForArchivePath(path) ?: throw IOException("Invalid media destination: $path")
                val expected = AttachmentStore.sha256(from)
                if (to.exists()) {
                    if (!to.isFile || to.length() != from.length() || !AttachmentStore.sha256(to).equals(expected, true)) throw IOException("Media ID collision: $path")
                    continue
                }
                to.parentFile?.mkdirs()
                val temp = File(to.parentFile, ".import-${UUID.randomUUID()}-${to.name}")
                try {
                    FileInputStream(from).use { input -> FileOutputStream(temp).use { out -> input.copyTo(out, 128 * 1024); out.fd.sync() } }
                    if (temp.length() != from.length() || !AttachmentStore.sha256(temp).equals(expected, true)) throw IOException("Committed media integrity mismatch: $path")
                    if (!temp.renameTo(to)) throw IOException("Cannot install media: $path")
                    installed.add(to)
                } finally { temp.delete() }
            }
            val current = repository.all()
            val imported = List(incoming.length()) { JSONObject(incoming.getJSONObject(it).toString()) }
            val result = when (mode) {
                0 -> addOnly(current, imported)
                1 -> merge(current, imported)
                else -> imported
            }
            val normalized = PostRules.enforceSingleSuperStar(JSONArray().apply { result.forEach { put(it) } })
            repository.replace(List(normalized.length()) { normalized.getJSONObject(it) })
            activity.runOnUiThread { onChanged(); Toast.makeText(activity, if (isZh()) "导入完成：${imported.size} 条笔记" else "Import complete: ${imported.size} posts", Toast.LENGTH_SHORT).show() }
        } catch (e: Exception) {
            installed.forEach { it.delete() }
            toast((if (isZh()) "导入失败：" else "Import failed: ") + (e.message ?: "unknown error"))
        } finally { stage.deleteRecursively() }
    }

    private fun addOnly(current: List<JSONObject>, imported: List<JSONObject>): List<JSONObject> {
        val keys = current.map { identity(it) }.toMutableSet(); val out = current.map { JSONObject(it.toString()) }.toMutableList()
        imported.forEach { if (keys.add(identity(it))) out.add(it) }
        return out
    }

    private fun merge(current: List<JSONObject>, imported: List<JSONObject>): List<JSONObject> {
        val out = current.map { JSONObject(it.toString()) }.toMutableList()
        imported.forEach { incoming ->
            val key = identity(incoming); val i = out.indexOfFirst { identity(it) == key }
            if (i < 0) out.add(incoming) else if (isIncomingNewer(incoming, out[i])) out[i] = incoming
        }
        return out
    }

    private fun identity(p: JSONObject): String = p.optString("uuid").ifBlank { p.opt("id")?.toString().orEmpty() }.ifBlank { NoteIdentity.create().also { p.put("uuid", it) } }
    private fun isIncomingNewer(a: JSONObject, b: JSONObject): Boolean {
        fun time(p: JSONObject): Long = runCatching { Instant.parse(p.optString("updatedAt", p.optString("createdAt"))).toEpochMilli() }.getOrDefault(0L)
        return time(a) >= time(b)
    }

    private fun normalizedPosts(source: List<JSONObject>) = normalizedPosts(JSONArray().apply { source.forEach { put(JSONObject(it.toString())) } })
    private fun normalizedPosts(source: JSONArray): JSONArray = JSONArray().apply {
        for (i in 0 until source.length()) {
            val p = JSONObject(source.getJSONObject(i).toString())
            if (!p.has("uuid") || p.optString("uuid").isBlank()) p.put("uuid", NoteIdentity.create())
            if (!p.has("archived") || p.opt("archived") !is Boolean) p.put("archived", p.optBoolean("archived", false))
            p.put("starState", PostRules.normalizeStarState(p.optString("starState")))
            put(p)
        }
    }

    private fun verifyArchive(file: File, media: Set<String>) {
        ZipFile(file).use { zip ->
            listOf("manifest.json", "data/posts.json", "checksums.json").forEach { if (zip.getEntry(it) == null) throw IOException("Export missing $it") }
            val checks = JSONObject(readLimited(zip.getInputStream(zip.getEntry("checksums.json")), MAX_METADATA).toString(StandardCharsets.UTF_8))
            val posts = JSONArray(readLimited(zip.getInputStream(zip.getEntry("data/posts.json")), MAX_METADATA).toString(StandardCharsets.UTF_8))
            for (i in 0 until posts.length()) if (posts.optJSONObject(i)?.opt("archived") !is Boolean) throw IOException("Post $i is missing boolean archived state")
            for (key in checks.keys()) {
                val entry = zip.getEntry(key) ?: throw IOException("Export missing $key")
                if (!sha256(zip.getInputStream(entry)).equals(checks.getString(key), true)) throw IOException("Export checksum failed: $key")
            }
            for (path in media) if (!checks.has(path)) throw IOException("Unchecked media: $path")
            val actualMedia = zip.entries().asSequence().map { it.name }.filter { it.startsWith("media/") && !it.endsWith("/") }.toSet()
            if (actualMedia != media) throw IOException("Export media set does not match posts")
        }
    }

    private fun validateAttachmentMetadata(posts: JSONArray, resolve: (String) -> File?) {
        val ids = mutableMapOf<String, String>()
        for (i in 0 until posts.length()) {
            val attachments = posts.optJSONObject(i)?.optJSONArray("attachments") ?: continue
            for (j in 0 until attachments.length()) {
                val item = attachments.getJSONObject(j); val id = item.optString("id")
                val path = toMediaPath(item.optString("path")) ?: toMediaPath(item.optString("url")) ?: toMediaPath(item.optString("src")) ?: throw IOException("Attachment has no durable path: $id")
                val file = resolve(path) ?: throw IOException("Invalid attachment path: $path")
                if (id.isBlank() || !file.isFile) throw IOException("Missing attachment: $path")
                if (ids.put(id, path)?.let { it != path } == true) throw IOException("Media ID collision: $id")
                val hash = AttachmentStore.sha256(file)
                if (item.has("size") && !item.isNull("size") && item.getLong("size") != file.length()) throw IOException("Attachment size mismatch: $path")
                if (item.optString("sha256").isNotEmpty() && !hash.equals(item.getString("sha256"), true)) throw IOException("Attachment checksum mismatch: $path")
                item.put("path", path).put("size", file.length()).put("sha256", hash)
                if (item.optString("mimeType").isBlank()) item.put("mimeType", store.mimeForFileName(file.name))
            }
        }
    }

    private fun collectMediaPaths(posts: JSONArray): LinkedHashSet<String> {
        val out = LinkedHashSet<String>()
        fun visit(value: Any?) {
            when (value) {
                is JSONObject -> {
                    val keys = value.keys()
                    while (keys.hasNext()) visit(value.opt(keys.next()))
                }
                is JSONArray -> for (i in 0 until value.length()) visit(value.opt(i))
                is String -> toMediaPath(value)?.let { out.add(it) }
            }
        }
        visit(posts)
        return out
    }
    private fun toMediaPath(value: String): String? = when {
        Regex("^media/[A-Za-z0-9_.-]+$").matches(value) -> value
        Regex("^https://appassets\\.androidplatform\\.net/media/[A-Za-z0-9_.-]+$").matches(value) ->
            value.substringAfter("https://appassets.androidplatform.net/")
        else -> null
    }

    private fun putCheckedText(zip: ZipOutputStream, name: String, text: String, checksums: JSONObject) {
        val bytes = text.toByteArray(StandardCharsets.UTF_8)
        zip.putNextEntry(ZipEntry(name))
        zip.write(bytes)
        zip.closeEntry()
        checksums.put(name, sha256(bytes))
    }

    private fun sha256(bytes: ByteArray): String =
        AttachmentStore.hex(MessageDigest.getInstance("SHA-256").digest(bytes))

    private fun sha256(input: InputStream): String = input.use { stream ->
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(64 * 1024)
        while (true) {
            val bytesRead = stream.read(buffer)
            if (bytesRead < 0) break
            digest.update(buffer, 0, bytesRead)
        }
        AttachmentStore.hex(digest.digest())
    }

    private fun isoNow(): String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }.format(Date())

    private fun normalizeEntry(name: String): String = name.replace('\\', '/')

    private fun validateEntry(name: String) {
        val metadataEntries = setOf("manifest.json", "checksums.json", "data/posts.json")
        val validMediaEntry = Regex("^media/[A-Za-z0-9_.-]+$").matches(name)
        if (name.isBlank() || name.startsWith('/') || name.contains("..") || (name !in metadataEntries && !validMediaEntry)) {
            throw IOException("Invalid archive entry: $name")
        }
    }

    private fun safeFile(root: File, name: String): File {
        val file = File(root, name).canonicalFile
        if (!file.path.startsWith(root.canonicalPath + File.separator)) throw IOException("Unsafe archive path")
        return file
    }

    private fun readUtf8(file: File): String =
        String(readLimited(FileInputStream(file), MAX_METADATA), StandardCharsets.UTF_8)

    private fun readLimited(input: InputStream, maxBytes: Long): ByteArray = input.use { stream ->
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(32 * 1024)
        var totalBytes = 0L
        while (true) {
            val bytesRead = stream.read(buffer)
            if (bytesRead < 0) break
            totalBytes += bytesRead
            if (totalBytes > maxBytes) throw IOException("Metadata too large")
            output.write(buffer, 0, bytesRead)
        }
        output.toByteArray()
    }

    private fun copyLimited(input: InputStream, output: OutputStream, maxBytes: Long) {
        val buffer = ByteArray(64 * 1024)
        var totalBytes = 0L
        while (true) {
            val bytesRead = input.read(buffer)
            if (bytesRead < 0) break
            totalBytes += bytesRead
            if (totalBytes > maxBytes) throw IOException("Backup exceeds 128 MiB")
            output.write(buffer, 0, bytesRead)
        }
    }
    private fun isZh()=UiLanguage.languageCode(activity)=="zh"
    private fun toast(message:String)=activity.runOnUiThread{Toast.makeText(activity,message,Toast.LENGTH_LONG).show()}
    fun destroy(){io.shutdownNow()}
}
