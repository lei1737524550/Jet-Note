package leo.lei.note

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.VideoView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class NativePostViewerActivity : Activity() {
    private lateinit var transitionTopBar: View
    private lateinit var transitionContent: View
    private var closing = false
    companion object { const val EXTRA_POST_JSON = "post_json" }

    private lateinit var store: AttachmentStore
    private lateinit var post: JSONObject
    private val legacy by lazy { LegacyUiMetrics(this) }
    private fun px(v: Float) = legacy.px(v)
    private fun sp(v: Float) = legacy.sp(v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeStore.applyWindow(this)
        post = runCatching { JSONObject(intent.getStringExtra(EXTRA_POST_JSON).orEmpty()) }.getOrElse { finish(); return }
        store = AttachmentStore(this)
        val theme = ThemeStore.current(this)
        window.statusBarColor = theme.topColor
        window.navigationBarColor = theme.bodyColor
        setContentView(buildUi())
    }

    private fun buildUi(): View {
        val theme = ThemeStore.current(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(theme.topColor)
            fitsSystemWindows = false
            setOnApplyWindowInsetsListener { v, insets ->
                v.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop, insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
                insets
            }
        }

        val top = NativeTopBar.build(
            this,
            if (UiLanguage.languageCode(this) == "zh") "查看笔记" else "Post Viewer",
            leftRes = R.drawable.jet_editor_close, onLeft = { finishWithReverseAnimation() }
        )
        root.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(NativeTopBar.HEIGHT_DP.toFloat())))
        transitionTopBar = top

        val scroll = ScrollView(this).apply {
            setBackgroundColor(theme.bodyColor)
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20f), px(22f), px(20f), px(32f))
        }
        scroll.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        transitionContent = scroll
        

        val title = post.optString("title")
        if (title.isNotBlank()) content.addView(TextView(this).apply {
            text = title; textSize = sp(20.7f); setTextColor(theme.foregroundColor)
            setPadding(0, 0, 0, px(10f))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = px(16f) })

        content.addView(TextView(this).apply {
            text = styledText(post); textSize = sp(17f); setTextColor(theme.foregroundColor)
            setTextIsSelectable(true); gravity = Gravity.START; includeFontPadding = true
            setLineSpacing(0f, 1.55f)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        addAttachments(content)
        return root
    }

    private fun finishWithReverseAnimation() {
        if (closing) return
        if (!::transitionTopBar.isInitialized || !::transitionContent.isInitialized) { PageActivityTransition.finish(this); return }
        closing = true
        PageActivityTransition.finish(this)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = finishWithReverseAnimation()

    private fun styledText(p: JSONObject): SpannableStringBuilder {
        val raw = p.optString("text")
        val out = SpannableStringBuilder(raw)
        val n = raw.length
        fun range(o: JSONObject): Pair<Int, Int>? {
            val a = o.optInt("start").coerceIn(0, n); val b = o.optInt("end").coerceIn(0, n)
            return if (b > a) a to b else null
        }
        p.optJSONArray("styleCommands")?.objects()?.forEach { c -> range(c)?.let { (a,b) ->
            when(c.optString("style")) {
                "bold" -> out.setSpan(StyleSpan(Typeface.BOLD),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                "italic" -> out.setSpan(StyleSpan(Typeface.ITALIC),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                "underline" -> out.setSpan(UnderlineSpan(),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                "strike" -> out.setSpan(StrikethroughSpan(),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                "overline" -> out.setSpan(OverlineSpan(),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }}
        p.optJSONArray("fontCommands")?.objects()?.forEach { c -> range(c)?.let { (a,b) ->
            val family = when(c.optString("font")) { "serif" -> "serif"; "monospace" -> "monospace"; else -> "sans-serif" }
            out.setSpan(TypefaceSpan(family),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }}
        val colors = p.optJSONArray("colorCommands")?.objects()?.sortedBy { it.optInt("offset") }.orEmpty()
        colors.forEachIndexed { i,c ->
            val value = c.optString("color").takeIf { it.matches(Regex("#[0-9A-Fa-f]{6}")) } ?: return@forEachIndexed
            val a = c.optInt("offset").coerceIn(0,n)
            val b = (colors.getOrNull(i+1)?.optInt("offset") ?: n).coerceIn(a,n)
            if (b>a) runCatching { out.setSpan(ForegroundColorSpan(Color.parseColor(value)),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE) }
        }
        return out
    }

    private fun addAttachments(parent: LinearLayout) {
        val seen = HashSet<String>()
        val items = mutableListOf<JSONObject>()
        post.optJSONArray("attachments")?.objects()?.forEach { items += it }
        post.optJSONArray("images")?.let { a -> for(i in 0 until a.length()) {
            val src=a.optString(i); val path=src.substringAfter("https://appassets.androidplatform.net/", src)
            if(path.startsWith("media/")) items += JSONObject().put("type","image").put("path",path)
        }}
        items.forEach { item ->
            val type=item.optString("type")
            val path=item.optString("path").removePrefix("https://appassets.androidplatform.net/")
            if(path.isBlank() || !seen.add("$type:$path")) return@forEach
            val file=store.fileForArchivePath(path) ?: return@forEach
            if(!file.isFile) return@forEach
            when(type) {
                "image" -> addImage(parent,file)
                "video" -> addVideo(parent,file)
                "audio" -> addAudio(parent,file)
            }
        }
    }

    private fun addImage(parent: LinearLayout, file: File) {
        val bounds=android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds=true }
        android.graphics.BitmapFactory.decodeFile(file.absolutePath,bounds)
        val ratio=if(bounds.outWidth>0 && bounds.outHeight>0) bounds.outHeight.toFloat()/bounds.outWidth else 1f
        val iv=ImageView(this).apply {
            adjustViewBounds=true; scaleType=ImageView.ScaleType.FIT_START
            BitmapLoader.decode(file, resources.displayMetrics.widthPixels, (resources.displayMetrics.heightPixels * 0.75f).toInt())?.let(::setImageBitmap)
            setOnClickListener { startActivity(Intent(this@NativePostViewerActivity,NativeImageViewerActivity::class.java).putExtra(NativeImageViewerActivity.EXTRA_FILE_PATH,file.absolutePath));overridePendingTransition(R.anim.page_enter_from_left, 0) }
        }
        parent.addView(iv,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin=px(18f)
            if(ratio>1.35f) width=(resources.displayMetrics.widthPixels*0.62f).toInt() // narrow portrait: left aligned, never centered
        })
    }

    private fun addVideo(parent: LinearLayout, file: File) {
        val vv=VideoView(this).apply {
            setVideoPath(file.absolutePath)
            setOnClickListener { if(isPlaying) pause() else start() }
            setOnLongClickListener { startActivity(Intent(this@NativePostViewerActivity,NativeVideoViewerActivity::class.java).putExtra(NativeVideoViewerActivity.EXTRA_FILE_PATH,file.absolutePath));overridePendingTransition(R.anim.page_enter_from_left, 0); true }
        }
        parent.addView(vv,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,px(220f)).apply { topMargin=px(18f) })
    }

    private fun addAudio(parent: LinearLayout, file: File) {
        val button=TextView(this).apply {
            text="▶  ${file.name}"; textSize=sp(15f); setTextColor(ThemeStore.current(this@NativePostViewerActivity).foregroundColor)
            gravity=Gravity.CENTER_VERTICAL; setPadding(px(12f),0,px(12f),0)
            var player:MediaPlayer?=null
            setOnClickListener {
                val p=player
                if(p==null){ player=MediaPlayer.create(this@NativePostViewerActivity,Uri.fromFile(file))?.also { mp -> mp.setOnCompletionListener { text="▶  ${file.name}"; mp.release(); player=null }; mp.start(); text="Ⅱ  ${file.name}" } }
                else if(p.isPlaying){p.pause();text="▶  ${file.name}"} else {p.start();text="Ⅱ  ${file.name}"}
            }
        }
        parent.addView(button,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,px(48f)).apply { topMargin=px(12f) })
    }

    private fun JSONArray.objects(): List<JSONObject> = buildList { for(i in 0 until length()) optJSONObject(i)?.let(::add) }
}
