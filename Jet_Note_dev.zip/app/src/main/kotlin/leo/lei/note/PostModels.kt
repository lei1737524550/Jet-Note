package leo.lei.note

import org.json.JSONArray
import org.json.JSONObject

enum class StarState(val wireValue: String) {
    NONE("none"), STAR("star"), SUPER_STAR("super_star");
    companion object { fun from(value: String?): StarState = entries.firstOrNull { it.wireValue == value } ?: NONE }
}

data class Attachment(
    val id: String,
    val type: String,
    val mimeType: String,
    val originalName: String?,
    val path: String,
    val size: Long,
    val sha256: String,
    val durationSeconds: Double?,
    val width: Int?,
    val height: Int?,
    val extra: JSONObject = JSONObject()
)

data class Post(
    val id: String,
    val uuid: String,
    val title: String,
    val text: String,
    val attachments: List<Attachment>,
    val archived: Boolean,
    val starState: StarState,
    val createdAt: String?,
    val updatedAt: String?,
    val favoritedAt: String?,
    val raw: JSONObject
)

internal object PostCodec {
    fun decode(source: JSONObject): Post {
        val raw = JSONObject(source.toString())
        return Post(
            id = raw.opt("id")?.toString().orEmpty(),
            uuid = raw.optString("uuid", ""),
            title = raw.optString("title", ""),
            text = raw.optString("text", ""),
            attachments = decodeAttachments(raw.optJSONArray("attachments")),
            archived = raw.optBoolean("archived", false),
            starState = StarState.from(raw.optString("starState", "none")),
            createdAt = raw.optString("createdAt").takeIf(String::isNotBlank),
            updatedAt = raw.optString("updatedAt").takeIf(String::isNotBlank),
            favoritedAt = raw.optString("favoritedAt").takeIf(String::isNotBlank),
            raw = raw
        )
    }

    fun encode(post: Post): JSONObject = JSONObject(post.raw.toString()).apply {
        put("id", post.id)
        put("uuid", post.uuid)
        put("title", post.title)
        put("text", post.text)
        put("attachments", JSONArray().apply { post.attachments.forEach { put(encodeAttachment(it)) } })
        put("archived", post.archived)
        put("starState", post.starState.wireValue)
        post.createdAt?.let { put("createdAt", it) }
        post.updatedAt?.let { put("updatedAt", it) }
        post.favoritedAt?.let { put("favoritedAt", it) }
    }

    fun decodeAttachment(source: JSONObject): Attachment = Attachment(
        id = source.optString("id", ""), type = source.optString("type", ""),
        mimeType = source.optString("mimeType", "application/octet-stream"),
        originalName = source.optString("originalName").takeIf(String::isNotBlank),
        path = source.optString("path", ""), size = source.optLong("size", 0L),
        sha256 = source.optString("sha256", ""),
        durationSeconds = if (source.isNull("duration")) null else source.optDouble("duration"),
        width = if (source.isNull("width")) null else source.optInt("width"),
        height = if (source.isNull("height")) null else source.optInt("height"),
        extra = source.optJSONObject("extra")?.let { JSONObject(it.toString()) } ?: JSONObject()
    )

    fun encodeAttachment(value: Attachment): JSONObject = JSONObject().apply {
        put("id", value.id); put("type", value.type); put("mimeType", value.mimeType)
        put("originalName", value.originalName ?: JSONObject.NULL); put("path", value.path)
        put("size", value.size); put("sha256", value.sha256)
        put("duration", value.durationSeconds ?: JSONObject.NULL)
        put("width", value.width ?: JSONObject.NULL); put("height", value.height ?: JSONObject.NULL)
        put("extra", JSONObject(value.extra.toString()))
    }

    fun decodeAttachments(source: JSONArray?): List<Attachment> = if (source == null) emptyList() else
        List(source.length()) { source.optJSONObject(it) }.filterNotNull().map(::decodeAttachment)
}
