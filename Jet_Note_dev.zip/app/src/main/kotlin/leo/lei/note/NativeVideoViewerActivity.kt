package leo.lei.note

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.MediaController
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class NativeVideoViewerActivity : Activity(), TextureView.SurfaceTextureListener,
    MediaController.MediaPlayerControl {

    companion object {
        const val REQUEST_CODE = 64107
        const val EXTRA_FILE_PATH = "jetnote.video.file"
        const val EXTRA_MEDIA_ID = "jetnote.video.media_id"
        const val EXTRA_START_MS = "jetnote.video.start_ms"
        const val RESULT_MEDIA_ID = "jetnote.video.result.media_id"
        const val RESULT_POSITION_MS = "jetnote.video.result.position_ms"
        const val RESULT_DURATION_MS = "jetnote.video.result.duration_ms"

        private const val TOUCH_SLOP_PX = 12f
    }

    private var root: FrameLayout? = null
    private var textureView: TextureView? = null
    private var mediaPlayer: MediaPlayer? = null
    private var mediaController: MediaController? = null
    private var transitionTopBar: View? = null
    private var closing = false

    private var mediaId = ""
    private var filePath = ""
    private var requestedStartMs = 0
    private var knownDurationMs = 0
    private var prepared = false
    private var resultSent = false
    private var resumeAfterLifecyclePause = false
    private var configuredMaximumScale = -1f
    private var currentScale = 1f
    private var currentTranslationX = 0f
    private var currentTranslationY = 0f
    private val videoContentMatrix = Matrix()

    private var pinchOccurred = false
    private var panOccurred = false
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var touchDownX = 0f
    private var touchDownY = 0f
    private var pinchStartDistance = 0f
    private var pinchStartScale = 1f
    private var pinchStartFocusX = 0f
    private var pinchStartFocusY = 0f
    private var pinchStartTranslationX = 0f
    private var pinchStartTranslationY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setStatusBarColor(Color.BLACK)
        window.setNavigationBarColor(Color.BLACK)
        configuredMaximumScale = readConfiguredMaximumScale()

        val input = intent
        mediaId = input?.getStringExtra(EXTRA_MEDIA_ID).orEmpty()
        requestedStartMs = max(0, input?.getIntExtra(EXTRA_START_MS, 0) ?: 0)
        val path = input?.getStringExtra(EXTRA_FILE_PATH)
        if (path == null || !File(path).isFile) {
            finishWithPosition()
            return
        }
        filePath = path

        val rootView = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        root = rootView

        val videoView = TextureView(this).apply {
            isOpaque = false
            surfaceTextureListener = this@NativeVideoViewerActivity
        }
        textureView = videoView
        rootView.addView(
            videoView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            )
        )

        val controller = MediaController(this).apply {
            setMediaPlayer(this@NativeVideoViewerActivity)
            setAnchorView(rootView)
        }
        mediaController = controller
        rootView.post { hideMediaControllerSeekButtons() }

        installViewerZoomAndPan()

        val topBar = NativeTopBar.build(
            this,
            if (UiLanguage.languageCode(this) == "zh") "视频查看器" else "Video Viewer",
            leftRes = R.drawable.jet_editor_close,
            onLeft = { finishWithPosition() }
        )
        rootView.addView(topBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(NativeTopBar.HEIGHT_DP), Gravity.TOP))
        transitionTopBar = topBar
        val close = topBar.getChildAt(1)
        close.setOnLongClickListener {
            MediaFileManager.downloadFile(this@NativeVideoViewerActivity, File(filePath), mimeForVideoFile(filePath), "video")
            true
        }
        SystemInsets.listen(topBar) { safe ->
            topBar.setPadding(0, safe.top, 0, 0)
            topBar.layoutParams = (topBar.layoutParams as FrameLayout.LayoutParams).apply { height = safe.top + dp(NativeTopBar.HEIGHT_DP) }
        }

        setContentView(rootView)
        
    }

    private fun createAndPreparePlayer(surfaceTexture: SurfaceTexture) {
        releasePlayer()
        try {
            val player = MediaPlayer()
            mediaPlayer = player
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )

            val surface = Surface(surfaceTexture)
            try {
                player.setSurface(surface)
            } finally {
                surface.release()
            }

            player.setDataSource(filePath)
            player.setOnPreparedListener { mp ->
                if (mediaPlayer !== mp) return@setOnPreparedListener
                prepared = true
                knownDurationMs = max(0, mp.duration)
                updateVideoDisplaySize(mp.videoWidth, mp.videoHeight)
                val target = if (knownDurationMs > 0) {
                    min(requestedStartMs, max(0, knownDurationMs - 1))
                } else {
                    requestedStartMs
                }
                if (target > 0) mp.seekTo(target)
                mp.start()
                mediaController?.let { controller ->
                    controller.isEnabled = true
                    controller.show(3000)
                    hideMediaControllerSeekButtons()
                }
            }
            player.setOnVideoSizeChangedListener { _, width, height ->
                updateVideoDisplaySize(width, height)
            }
            player.setOnCompletionListener {
                knownDurationMs = max(knownDurationMs, getDuration())
                mediaController?.show(0)
            }
            player.setOnErrorListener { _, _, _ ->
                finishWithPosition()
                true
            }
            player.prepareAsync()
        } catch (_: Exception) {
            finishWithPosition()
        }
    }

    
    private fun updateVideoDisplaySize(videoWidth: Int, videoHeight: Int) {
        val rootView = root ?: return
        val videoView = textureView ?: return
        if (videoWidth <= 0 || videoHeight <= 0) return

        rootView.post {
            val currentRoot = root ?: return@post
            val currentVideo = textureView ?: return@post
            val availableWidth = currentRoot.width
            val availableHeight = currentRoot.height
            if (availableWidth <= 0 || availableHeight <= 0) return@post

            val videoRatio = videoWidth.toFloat() / videoHeight.toFloat()
            val screenRatio = availableWidth.toFloat() / availableHeight.toFloat()
            val displayWidth: Int
            val displayHeight: Int
            if (videoRatio > screenRatio) {
                displayWidth = availableWidth
                displayHeight = max(1, (availableWidth / videoRatio).roundToInt())
            } else {
                displayHeight = availableHeight
                displayWidth = max(1, (availableHeight * videoRatio).roundToInt())
            }

            val params = (currentVideo.layoutParams as FrameLayout.LayoutParams).apply {
                width = displayWidth
                height = displayHeight
                gravity = Gravity.CENTER
            }
            currentVideo.layoutParams = params
            currentTranslationX = 0f
            currentTranslationY = 0f
            applyViewerTransform()
        }
    }

    private fun installViewerZoomAndPan() {
        val videoView = textureView ?: return

        videoView.setOnTouchListener { _, event ->
            val action = event.actionMasked

            if (configuredMaximumScale == 0f) {
                if (action == MotionEvent.ACTION_UP) toggleController()
                return@setOnTouchListener true
            }

            when (action) {
                MotionEvent.ACTION_DOWN -> {
                    touchDownX = event.x
                    lastTouchX = event.x
                    touchDownY = event.y
                    lastTouchY = event.y
                    pinchOccurred = false
                    panOccurred = false
                    resetPinchBaseline()
                    true
                }

                MotionEvent.ACTION_POINTER_DOWN -> {
                    pinchOccurred = true
                    if (event.pointerCount >= 2) capturePinchBaseline(event)
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    if (event.pointerCount >= 2) {
                        pinchOccurred = true
                        applyPinchFromBaseline(event)
                        return@setOnTouchListener true
                    }

                    if (event.pointerCount == 1 && currentScale > 1.001f) {
                        val x = event.x
                        val y = event.y
                        val dx = x - lastTouchX
                        val dy = y - lastTouchY
                        if (abs(x - touchDownX) > TOUCH_SLOP_PX || abs(y - touchDownY) > TOUCH_SLOP_PX) {
                            panOccurred = true
                        }
                        currentTranslationX += dx
                        currentTranslationY += dy
                        lastTouchX = x
                        lastTouchY = y
                        clampTranslations()
                        applyViewerTransform()
                    }
                    true
                }

                MotionEvent.ACTION_POINTER_UP -> {
                    pinchOccurred = true
                    resetPinchBaseline()
                    if (event.pointerCount == 2) {
                        val lifted = event.actionIndex
                        val remaining = if (lifted == 0) 1 else 0
                        lastTouchX = event.getX(remaining)
                        lastTouchY = event.getY(remaining)
                        touchDownX = lastTouchX
                        touchDownY = lastTouchY
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    if (!pinchOccurred && !panOccurred) toggleController()
                    resetPinchBaseline()
                    true
                }

                MotionEvent.ACTION_CANCEL -> {
                    resetPinchBaseline()
                    true
                }

                else -> true
            }
        }
    }

    private fun capturePinchBaseline(event: MotionEvent?) {
        if (event == null || event.pointerCount < 2) return
        val dx = event.getX(1) - event.getX(0)
        val dy = event.getY(1) - event.getY(0)
        pinchStartDistance = hypot(dx.toDouble(), dy.toDouble()).toFloat()
        if (!pinchStartDistance.isFinite() || pinchStartDistance <= 0f) {
            pinchStartDistance = 0f
            return
        }
        pinchStartScale = currentScale
        pinchStartFocusX = (event.getX(0) + event.getX(1)) * 0.5f
        pinchStartFocusY = (event.getY(0) + event.getY(1)) * 0.5f
        pinchStartTranslationX = currentTranslationX
        pinchStartTranslationY = currentTranslationY
    }

    private fun applyPinchFromBaseline(event: MotionEvent?) {
        val videoView = textureView ?: return
        if (event == null || event.pointerCount < 2) return
        if (pinchStartDistance <= 0f) {
            capturePinchBaseline(event)
            return
        }

        val dx = event.getX(1) - event.getX(0)
        val dy = event.getY(1) - event.getY(0)
        val distance = hypot(dx.toDouble(), dy.toDouble()).toFloat()
        if (!distance.isFinite() || distance <= 0f) return

        val focusX = (event.getX(0) + event.getX(1)) * 0.5f
        val focusY = (event.getY(0) + event.getY(1)) * 0.5f
        val requestedScale = pinchStartScale * (distance / pinchStartDistance)
        val nextScale = constrainScale(requestedScale)
        if (!nextScale.isFinite() || nextScale <= 0f) return

        val ratio = nextScale / pinchStartScale
        val centerX = videoView.width * 0.5f
        val centerY = videoView.height * 0.5f
        currentTranslationX = focusX - centerX - ratio * (pinchStartFocusX - centerX - pinchStartTranslationX)
        currentTranslationY = focusY - centerY - ratio * (pinchStartFocusY - centerY - pinchStartTranslationY)
        currentScale = nextScale

        if (currentScale <= 1.001f) {
            currentScale = 1f
            currentTranslationX = 0f
            currentTranslationY = 0f
        } else {
            clampTranslations()
        }
        applyViewerTransform()
    }

    private fun resetPinchBaseline() {
        pinchStartDistance = 0f
        pinchStartScale = currentScale
        pinchStartFocusX = 0f
        pinchStartFocusY = 0f
        pinchStartTranslationX = currentTranslationX
        pinchStartTranslationY = currentTranslationY
    }

    private fun toggleController() {
        val controller = mediaController ?: return
        if (controller.isShowing) {
            controller.hide()
        } else {
            controller.show(3000)
            hideMediaControllerSeekButtons()
        }
    }

    
    private fun hideMediaControllerSeekButtons() {
        if (mediaController == null) return
        hideSystemMediaControllerChild("rew")
        hideSystemMediaControllerChild("ffwd")
    }

    private fun hideSystemMediaControllerChild(systemIdName: String) {
        val controller = mediaController ?: return
        val id = resources.getIdentifier(systemIdName, "id", "android")
        if (id == 0) return
        controller.findViewById<View>(id)?.visibility = View.GONE
    }

    private fun mimeForVideoFile(path: String?): String {
        val lower = path.orEmpty().lowercase(Locale.US)
        return when {
            lower.endsWith(".webm") -> "video/webm"
            lower.endsWith(".mov") -> "video/quicktime"
            lower.endsWith(".mkv") -> "video/x-matroska"
            lower.endsWith(".3gp") -> "video/3gpp"
            else -> "video/mp4"
        }
    }

    private fun constrainScale(candidate: Float): Float {
        if (configuredMaximumScale == 0f) return 1f
        var safeCandidate = candidate
        if (!safeCandidate.isFinite()) safeCandidate = Float.MAX_VALUE / 1024f
        safeCandidate = max(1f, safeCandidate)
        return if (configuredMaximumScale < 0f) {
            min(Float.MAX_VALUE / 1024f, safeCandidate)
        } else {
            min(max(1f, configuredMaximumScale), safeCandidate)
        }
    }

    private fun clampTranslations() {
        val videoView = textureView ?: run {
            currentScale = 1f
            currentTranslationX = 0f
            currentTranslationY = 0f
            return
        }
        if (currentScale <= 1.001f) {
            currentScale = 1f
            currentTranslationX = 0f
            currentTranslationY = 0f
            return
        }

        val viewportWidth = root?.width ?: videoView.width
        val viewportHeight = root?.height ?: videoView.height
        val scaledWidth = videoView.width * currentScale.toDouble()
        val scaledHeight = videoView.height * currentScale.toDouble()
        val maxXDouble = max(0.0, (scaledWidth - viewportWidth) * 0.5)
        val maxYDouble = max(0.0, (scaledHeight - viewportHeight) * 0.5)
        val maxX = min(maxXDouble, Float.MAX_VALUE / 4096.0).toFloat()
        val maxY = min(maxYDouble, Float.MAX_VALUE / 4096.0).toFloat()
        currentTranslationX = max(-maxX, min(maxX, currentTranslationX))
        currentTranslationY = max(-maxY, min(maxY, currentTranslationY))
    }

    private fun applyViewerTransform() {
        val videoView = textureView ?: return
        val centerX = videoView.width * 0.5f
        val centerY = videoView.height * 0.5f
        videoContentMatrix.reset()
        videoContentMatrix.setScale(currentScale, currentScale, centerX, centerY)
        videoContentMatrix.postTranslate(currentTranslationX, currentTranslationY)
        videoView.setTransform(videoContentMatrix)
        videoView.invalidate()
    }

    private fun readConfiguredMaximumScale(): Float {
        try {
            val configuration = JSONObject(RuntimeConfigStore.readEffective(this))
            return configuration.getJSONObject("viewer_media_scale")
                .getDouble("video_viewer_max_scale")
                .toFloat()
        } catch (error: org.json.JSONException) {
            throw IllegalStateException(
                "Missing or invalid viewer_media_scale.video_viewer_max_scale",
                error
            )
        }
    }

    override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
        createAndPreparePlayer(surface)
    }

    override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) = Unit

    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
        releasePlayer()
        return true
    }

    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) = Unit
    override fun start() {
        if (prepared) mediaPlayer?.start()
    }

    override fun pause() {
        if (prepared) mediaPlayer?.pause()
    }

    override fun getDuration(): Int {
        val player = mediaPlayer
        if (!prepared || player == null) return max(0, knownDurationMs)
        return try {
            max(0, player.duration)
        } catch (_: RuntimeException) {
            max(0, knownDurationMs)
        }
    }

    override fun getCurrentPosition(): Int {
        val player = mediaPlayer
        if (!prepared || player == null) return max(0, requestedStartMs)
        return try {
            max(0, player.currentPosition)
        } catch (_: RuntimeException) {
            max(0, requestedStartMs)
        }
    }

    override fun seekTo(pos: Int) {
        if (prepared) mediaPlayer?.seekTo(max(0, pos))
    }

    override fun isPlaying(): Boolean {
        val player = mediaPlayer
        if (!prepared || player == null) return false
        return try {
            player.isPlaying
        } catch (_: RuntimeException) {
            false
        }
    }

    override fun getBufferPercentage(): Int = 100
    override fun canPause(): Boolean = true
    override fun canSeekBackward(): Boolean = true
    override fun canSeekForward(): Boolean = true

    override fun getAudioSessionId(): Int {
        val player = mediaPlayer ?: return 0
        return try {
            player.audioSessionId
        } catch (_: RuntimeException) {
            0
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        finishWithPosition()
    }

    override fun onPause() {
        super.onPause()
        resumeAfterLifecyclePause = isPlaying()
        if (resumeAfterLifecyclePause) pause()
    }

    override fun onResume() {
        super.onResume()
        if (resumeAfterLifecyclePause && prepared) {
            start()
            resumeAfterLifecyclePause = false
        }
    }

    override fun onDestroy() {
        if (!resultSent) sendResult()
        releasePlayer()
        super.onDestroy()
    }

    private fun releasePlayer() {
        val player = mediaPlayer
        mediaPlayer = null
        prepared = false
        if (player != null) {
            try {
                knownDurationMs = max(knownDurationMs, player.duration)
                requestedStartMs = max(0, player.currentPosition)
            } catch (_: RuntimeException) {
            }
            try {
                player.reset()
            } catch (_: RuntimeException) {
            }
            try {
                player.release()
            } catch (_: RuntimeException) {
            }
        }
    }

    private fun finishWithPosition() {
        if (closing) return
        sendResult()
        val bar = transitionTopBar
        val content = textureView
        if (bar == null || content == null) { PageActivityTransition.finish(this); return }
        closing = true
        mediaController?.hide()
        PageActivityTransition.finish(this)
    }

    private fun sendResult() {
        if (resultSent) return
        resultSent = true
        val current = getCurrentPosition()
        val duration = max(knownDurationMs, getDuration())
        val result = Intent().apply {
            putExtra(RESULT_MEDIA_ID, mediaId)
            putExtra(RESULT_POSITION_MS, current)
            putExtra(RESULT_DURATION_MS, max(0, duration))
        }
        setResult(RESULT_OK, result)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
}
