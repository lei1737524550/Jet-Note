package leo.lei.note

import android.graphics.Canvas
import android.graphics.Paint
import android.text.style.ReplacementSpan

class OverlineSpan : ReplacementSpan() {
    override fun getSize(paint: Paint, text: CharSequence, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int = paint.measureText(text, start, end).toInt()
    override fun draw(canvas: Canvas, text: CharSequence, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
        canvas.drawText(text, start, end, x, y.toFloat(), paint)
        val width=paint.measureText(text,start,end)
        val yy=y + paint.ascent() + paint.strokeWidth.coerceAtLeast(1f)
        canvas.drawLine(x, yy, x+width, yy, paint)
    }
}
