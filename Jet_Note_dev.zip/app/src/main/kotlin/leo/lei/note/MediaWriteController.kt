package leo.lei.note

import android.content.Context
import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID

internal class MediaWriteController(
    private val context: Context,
    private val store: AttachmentStore,
) {
    private val pending = HashMap<String, Pending>()

    @Synchronized
    fun begin(path: String): String {
        return try {
            val target = store.fileForArchivePath(path) ?: return ""
            if (pending.size >= 2) return ""
            val token = UUID.randomUUID().toString()
            val temp = File.createTempFile("media-write-", ".tmp", context.cacheDir)
            pending[token] = Pending(temp, target)
            token
        } catch (_: Exception) {
            ""
        }
    }

    @Synchronized
    fun append(token: String, encoded: String?): Boolean {
        val item = pending[token] ?: return false
        if (encoded == null || encoded.length > 200_000) return false
        return try {
            item.out.write(Base64.decode(encoded, Base64.DEFAULT))
            true
        } catch (_: Exception) {
            cancel(token)
            false
        }
    }

    @Synchronized
    fun finish(token: String, expected: String?): String {
        val item = pending.remove(token)
        return try {
            if (item == null) throw IOException("Media session expired")
            item.out.close()
            val hash = AttachmentStore.sha256(item.temp)
            if (!expected.isNullOrEmpty() && !expected.equals(hash, ignoreCase = true)) {
                throw IOException("Media checksum mismatch")
            }
            if (item.target.exists()) {
                if (hash != AttachmentStore.sha256(item.target)) {
                    throw IOException("Media path collision")
                }
            } else if (!item.temp.renameTo(item.target)) {
                throw IOException("Cannot commit media file")
            }
            JSONObject()
                .put("sha256", hash)
                .put("size", item.target.length())
                .toString()
        } catch (e: Exception) {
            error(e)
        } finally {
            item?.let {
                try {
                    it.out.close()
                } catch (_: Exception) {
                }
                it.temp.delete()
            }
        }
    }

    @Synchronized
    fun cancel(token: String) {
        pending.remove(token)?.let { item ->
            try {
                item.out.close()
            } catch (_: Exception) {
            }
            item.temp.delete()
        }
    }

    @Synchronized
    fun destroy() {
        pending.keys.toTypedArray().forEach(::cancel)
    }

    private class Pending(
        val temp: File,
        val target: File,
    ) {
        val out = FileOutputStream(temp)
    }

    companion object {
        fun error(e: Exception): String {
            val result = JSONObject()
            try {
                result.put("error", e.message ?: "media-error")
            } catch (_: Exception) {
            }
            return result.toString()
        }
    }
}
