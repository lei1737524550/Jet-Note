package leo.lei.note

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.database.Cursor
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

internal object MediaFileManager {
    enum class TaskType { DOWNLOAD, EXPORT }

    class Destination(
        @JvmField val uri: Uri,
        @JvmField val file: File?,
        @JvmField val fileName: String,
        @JvmField val mimeType: String
    ) {
        @JvmField var committed: Boolean = false
    }

    private val IO: ExecutorService = Executors.newSingleThreadExecutor()
    private val FEEDBACK_TAG = Any()

    @JvmStatic
    fun languageValue(activity: Activity, key: String): String = UiLanguage.text(activity, key)

    @JvmStatic
    fun targetDisplayPath(activity: Activity): String =
        UiLanguage.text(activity, "fileTaskDefaultDirectoryDisplayPath")

    @JvmStatic
    fun downloadUrl(activity: Activity?, url: String?, userAgent: String?, cookie: String?, referer: String?) {
        if (activity == null || url.isNullOrBlank() || !url.startsWith("https://")) {
            showFailed(activity, TaskType.DOWNLOAD, activity?.let { UiLanguage.text(it, "fileTaskUnknownFileName") } ?: "")
            return
        }
        IO.execute {
            var connection: HttpURLConnection? = null
            var destination: Destination? = null
            try {
                connection = URL(url).openConnection() as HttpURLConnection
                connection.instanceFollowRedirects = true
                connection.connectTimeout = 15000
                connection.readTimeout = 30000
                connection.setRequestProperty("Accept", "*/*")
                if (!userAgent.isNullOrEmpty()) connection.setRequestProperty("User-Agent", userAgent)
                if (!cookie.isNullOrEmpty()) connection.setRequestProperty("Cookie", cookie)
                if (!referer.isNullOrEmpty()) connection.setRequestProperty("Referer", referer)

                val code = connection.responseCode
                if (code !in 200..299) throw java.io.IOException("HTTP $code")

                val mime = normalizeMime(connection.contentType)
                val disposition = connection.getHeaderField("Content-Disposition")
                val fileName = sanitizeFileName(
                    guessFileName(connection.url.toString(), disposition, mime),
                    activity
                )
                destination = prepareDestination(activity, fileName, mime)
                    ?: throw java.io.IOException(UiLanguage.text(activity, "fileTaskStorageCreateFailed"))
                showStarted(activity, TaskType.DOWNLOAD, destination.fileName)

                connection.inputStream.use { input ->
                    copyWithLifecycle(activity, input, destination, TaskType.DOWNLOAD)
                }
            } catch (_: Exception) {
                destination?.let { abort(activity, it) }
                showFailed(activity, TaskType.DOWNLOAD, destination?.fileName ?: fileNameFromUrl(url, activity))
            } finally {
                connection?.disconnect()
            }
        }
    }

    @JvmStatic
    fun downloadFile(activity: Activity?, source: File?, mimeType: String?, mediaType: String?) {
        if (activity == null || source == null || !source.isFile) {
            showFailed(activity, TaskType.DOWNLOAD, activity?.let { UiLanguage.text(it, "fileTaskUnknownFileName") } ?: "")
            return
        }
        val mime = normalizeMimeForMedia(mimeType, source.name, mediaType)
        val fileName = if (source.name.trim().isEmpty()) {
            buildGeneratedName(activity, mediaType, mime)
        } else {
            sanitizeFileName(source.name, activity)
        }
        IO.execute {
            val destination = prepareDestination(activity, fileName, mime) ?: return@execute
            try {
                FileInputStream(source).use { input ->
                    copyWithLifecycle(activity, input, destination, TaskType.DOWNLOAD)
                }
            } catch (_: Exception) {
                abort(activity, destination)
                showFailed(activity, TaskType.DOWNLOAD, destination.fileName)
            }
        }
    }

    @JvmStatic
    fun downloadDataUrl(activity: Activity?, dataUrl: String?, mediaType: String?) {
        if (activity == null || dataUrl == null || !dataUrl.startsWith("data:")) {
            showFailed(activity, TaskType.DOWNLOAD, activity?.let { UiLanguage.text(it, "fileTaskUnknownFileName") } ?: "")
            return
        }
        IO.execute {
            var destination: Destination? = null
            try {
                val comma = dataUrl.indexOf(',')
                if (comma <= 5) throw IllegalArgumentException()
                val header = dataUrl.substring(5, comma)
                val mime = normalizeMimeForMedia(header.split(";", limit = 2)[0], null, mediaType)
                if (!header.lowercase(Locale.US).contains(";base64")) throw IllegalArgumentException()
                val bytes = android.util.Base64.decode(dataUrl.substring(comma + 1), android.util.Base64.DEFAULT)
                val fileName = buildGeneratedName(activity, mediaType, mime)
                destination = prepareDestination(activity, fileName, mime)
                if (destination == null) return@execute
                ByteArrayInputStream(bytes).use { input ->
                    copyWithLifecycle(activity, input, destination, TaskType.DOWNLOAD)
                }
            } catch (_: Exception) {
                destination?.let { abort(activity, it) }
                showFailed(
                    activity,
                    TaskType.DOWNLOAD,
                    destination?.fileName ?: UiLanguage.text(activity, "fileTaskUnknownFileName")
                )
            }
        }
    }

    @JvmStatic
    fun prepareExportDestination(activity: Activity, requestedFileName: String, mimeType: String): Destination? =
        prepareDestination(activity, requestedFileName, mimeType)

    @JvmStatic
    fun saveTextExport(activity: Activity?, requestedFileName: String, mimeType: String, text: String?) {
        if (activity == null) return
        val payload = text ?: ""
        IO.execute {
            val destination = prepareExportDestination(activity, requestedFileName, mimeType) ?: return@execute
            notifyExportStarted(activity, destination)
            try {
                openDestination(activity, destination).use { output ->
                    output.write(payload.toByteArray(Charsets.UTF_8))
                    output.flush()
                    completeExport(activity, destination)
                }
            } catch (_: Exception) {
                failExport(activity, destination)
            }
        }
    }

    @JvmStatic
    fun notifyExportStarted(activity: Activity, destination: Destination?) {
        if (destination != null) showStarted(activity, TaskType.EXPORT, destination.fileName)
    }

    @JvmStatic
    @Throws(Exception::class)
    fun openDestination(activity: Activity, destination: Destination): OutputStream {
        try {
            destination.file?.let { return FileOutputStream(it, false) }
            return activity.contentResolver.openOutputStream(destination.uri, "w")
                ?: throw java.io.IOException(UiLanguage.text(activity, "fileTaskStorageOpenFailed"))
        } catch (error: Exception) {
            showStorageUnavailable(activity)
            throw error
        }
    }

    @JvmStatic
    fun destinationSize(activity: Activity, destination: Destination?): Long {
        if (destination == null) return -1L
        destination.file?.let { return it.length() }
        try {
            activity.contentResolver.query(
                destination.uri,
                arrayOf(MediaStore.MediaColumns.SIZE),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(MediaStore.MediaColumns.SIZE)
                    if (index >= 0 && !cursor.isNull(index)) return cursor.getLong(index)
                }
            }
        } catch (_: Exception) {
        }
        return -1L
    }

    @JvmStatic
    @Throws(Exception::class)
    fun completeExport(activity: Activity, destination: Destination) {
        commit(activity, destination)
        showCompleted(activity, TaskType.EXPORT, destination.fileName)
    }

    @JvmStatic
    fun failExport(activity: Activity, destination: Destination?) {
        if (destination == null) return
        abort(activity, destination)
        showFailed(activity, TaskType.EXPORT, destination.fileName)
    }

    @Throws(Exception::class)
    private fun copyWithLifecycle(activity: Activity, input: InputStream, destination: Destination, type: TaskType) {
        openDestination(activity, destination).use { output ->
            val buffer = ByteArray(128 * 1024)
            var read = input.read(buffer)
            showStarted(activity, type, destination.fileName)
            if (read >= 0) {
                if (read > 0) output.write(buffer, 0, read)
                while (true) {
                    read = input.read(buffer)
                    if (read == -1) break
                    output.write(buffer, 0, read)
                }
            }
            output.flush()
        }
        commit(activity, destination)
        showCompleted(activity, type, destination.fileName)
    }

    private fun prepareDestination(activity: Activity, requestedFileName: String, mimeType: String): Destination? {
        try {
            val fileName = sanitizeFileName(requestedFileName, activity)
            val mime = normalizeMime(mimeType)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, relativeDirectory(activity))
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = activity.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw java.io.IOException(UiLanguage.text(activity, "fileTaskStorageCreateFailed"))
                val actualName = queryDisplayName(activity, uri, fileName)
                return Destination(uri, null, actualName, mime)
            }

            @Suppress("DEPRECATION")
            val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val directory = File(downloads, UiLanguage.text(activity, "fileTaskDefaultDirectoryName"))
            if ((!directory.exists() && !directory.mkdirs()) || !directory.isDirectory || !directory.canWrite()) {
                throw java.io.IOException(UiLanguage.text(activity, "fileTaskStorageCreateFailed"))
            }
            val file = uniqueFile(directory, fileName)
            return Destination(Uri.fromFile(file), file, file.name, mime)
        } catch (_: Exception) {
            showStorageUnavailable(activity)
            return null
        }
    }

    @Throws(Exception::class)
    private fun commit(activity: Activity, destination: Destination) {
        if (destination.committed) return
        if (destination.file == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val complete = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            val updated = activity.contentResolver.update(destination.uri, complete, null, null)
            if (updated <= 0) {
                showStorageUnavailable(activity)
                throw java.io.IOException(UiLanguage.text(activity, "fileTaskStorageCommitFailed"))
            }
        }
        destination.committed = true
    }

    @JvmStatic
    fun abort(activity: Activity?, destination: Destination?) {
        if (activity == null || destination == null) return
        try {
            if (destination.file != null) {
                if (destination.file.exists()) destination.file.delete()
            } else {
                activity.contentResolver.delete(destination.uri, null, null)
            }
        } catch (_: Exception) {
        }
    }

    private fun relativeDirectory(activity: Activity): String =
        Environment.DIRECTORY_DOWNLOADS + "/" + UiLanguage.text(activity, "fileTaskDefaultDirectoryName")

    private fun uniqueFile(directory: File, fileName: String): File {
        var candidate = File(directory, fileName)
        if (!candidate.exists()) return candidate
        val dot = fileName.lastIndexOf('.')
        val base = if (dot > 0) fileName.substring(0, dot) else fileName
        val ext = if (dot > 0) fileName.substring(dot) else ""
        for (i in 2 until 10000) {
            candidate = File(directory, "${base}_${i}$ext")
            if (!candidate.exists()) return candidate
        }
        return File(directory, "${base}_${System.currentTimeMillis()}$ext")
    }

    private fun queryDisplayName(activity: Activity, uri: Uri, fallback: String): String {
        try {
            activity.contentResolver.query(
                uri,
                arrayOf(MediaStore.MediaColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
                    if (index >= 0) {
                        val name = cursor.getString(index)
                        if (!name.isNullOrBlank()) return name
                    }
                }
            }
        } catch (_: Exception) {
        }
        return fallback
    }

    private fun showStarted(activity: Activity, type: TaskType, fileName: String) {
        showFeedback(
            activity,
            format(UiLanguage.text(activity, if (type == TaskType.EXPORT) "fileTaskExportStarted" else "fileTaskDownloadStarted"), fileName)
        )
    }

    private fun showCompleted(activity: Activity, type: TaskType, fileName: String) {
        showFeedback(
            activity,
            format(UiLanguage.text(activity, if (type == TaskType.EXPORT) "fileTaskExportCompleted" else "fileTaskDownloadCompleted"), fileName)
        )
    }

    private fun showFailed(activity: Activity?, type: TaskType, fileName: String) {
        if (activity == null) return
        showFeedback(
            activity,
            format(UiLanguage.text(activity, if (type == TaskType.EXPORT) "fileTaskExportFailed" else "fileTaskDownloadFailed"), fileName)
        )
    }

    @JvmStatic
    fun showFeedback(activity: Activity?, message: String) {
        if (activity == null) return
        activity.runOnUiThread {
            val root = activity.findViewById<ViewGroup>(android.R.id.content)
            if (root !is FrameLayout) return@runOnUiThread

            var stack = root.findViewWithTag<LinearLayout>(FEEDBACK_TAG)
            if (stack == null) {
                stack = LinearLayout(activity).apply {
                    tag = FEEDBACK_TAG
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                }
                val stackParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM
                ).apply {
                    leftMargin = dp(activity, 16)
                    rightMargin = dp(activity, 16)
                    bottomMargin = dp(activity, 88)
                }
                root.addView(stack, stackParams)
            }

            val feedbackStack = stack
            val text = TextView(activity).apply {
                this.text = UiLanguage.text(activity, "fileTaskFeedbackAppTitle") + "\n" + message
                setTextColor(Color.rgb(34, 34, 34))
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(dp(activity, 20), dp(activity, 12), dp(activity, 20), dp(activity, 12))
                background = GradientDrawable().apply {
                    setColor(Color.rgb(250, 255, 240))
                    cornerRadius = dp(activity, 18).toFloat()
                    setStroke(dp(activity, 1), Color.rgb(191, 193, 196))
                }
            }

            val textParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(activity, 6) }
            feedbackStack.addView(text, textParams)

            val duration = UiLanguage.longValue(activity, "fileTaskFeedbackDurationMs", 1400L)
            text.postDelayed({
                if (text.parent === feedbackStack) feedbackStack.removeView(text)
                if (feedbackStack.childCount == 0 && feedbackStack.parent === root) root.removeView(feedbackStack)
            }, maxOf(250L, duration))
        }
    }

    private fun showStorageUnavailable(activity: Activity?) {
        if (activity == null) return
        activity.runOnUiThread {
            val path = targetDisplayPath(activity)
            val message = UiLanguage.text(activity, "fileTaskStorageUnavailableMessage").replace("{path}", path)
            AlertDialog.Builder(activity)
                .setTitle(UiLanguage.text(activity, "fileTaskStorageUnavailableTitle"))
                .setMessage(message)
                .setPositiveButton(UiLanguage.text(activity, "fileTaskStorageUnavailableButton"), null)
                .show()
        }
    }

    private fun format(template: String, fileName: String?): String =
        template.replace("{fileName}", fileName ?: "")

    private fun sanitizeFileName(name: String?, activity: Activity): String {
        var value = (name ?: "").trim().replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_")
        if (value.isEmpty()) value = UiLanguage.text(activity, "fileTaskUnknownFileName")
        if (value.length > 180) value = value.substring(value.length - 180)
        return value
    }

    private fun fileNameFromUrl(url: String, activity: Activity): String = try {
        sanitizeFileName(guessFileName(url, null, null), activity)
    } catch (_: Exception) {
        UiLanguage.text(activity, "fileTaskUnknownFileName")
    }

    private fun normalizeMime(mimeType: String?): String {
        var mime = (mimeType ?: "").trim().lowercase(Locale.US)
        val semicolon = mime.indexOf(';')
        if (semicolon >= 0) mime = mime.substring(0, semicolon).trim()
        return mime.ifEmpty { "application/octet-stream" }
    }

    private fun normalizeMimeForMedia(mimeType: String?, fileName: String?, mediaType: String?): String {
        val mime = normalizeMime(mimeType)
        if (mime != "application/octet-stream") return mime
        val lower = (fileName ?: "").lowercase(Locale.US)
        return when {
            lower.endsWith(".png") -> "image/png"
            lower.endsWith(".gif") -> "image/gif"
            lower.endsWith(".webp") -> "image/webp"
            lower.endsWith(".svg") -> "image/svg+xml"
            lower.endsWith(".webm") -> "video/webm"
            lower.endsWith(".mov") -> "video/quicktime"
            lower.endsWith(".mkv") -> "video/x-matroska"
            lower.endsWith(".3gp") -> "video/3gpp"
            lower.endsWith(".mp4") -> "video/mp4"
            mediaType == "video" -> "video/mp4"
            else -> "image/jpeg"
        }
    }

    private fun buildGeneratedName(activity: Activity, mediaType: String?, mimeType: String): String {
        val datePattern = UiLanguage.text(activity, "fileTaskGeneratedMediaDatePattern")
        val stamp = SimpleDateFormat(datePattern, Locale.US).format(Date())
        val pattern = if (mediaType == "video") {
            UiLanguage.text(activity, "fileTaskGeneratedVideoFileNamePattern")
        } else {
            UiLanguage.text(activity, "fileTaskGeneratedImageFileNamePattern")
        }
        return pattern.replace("{date}", stamp).replace("{extension}", extensionForMime(mimeType))
    }

    private fun extensionForMime(mimeType: String?): String = when (mimeType?.lowercase(Locale.US)) {
        "image/jpeg" -> ".jpg"
        "image/png" -> ".png"
        "image/gif" -> ".gif"
        "image/webp" -> ".webp"
        "image/svg+xml" -> ".svg"
        "video/mp4" -> ".mp4"
        "video/webm" -> ".webm"
        "video/quicktime" -> ".mov"
        "video/x-matroska" -> ".mkv"
        "video/3gpp" -> ".3gp"
        else -> ".bin"
    }

    private fun dp(activity: Activity, value: Int): Int =
        Math.round(value * activity.resources.displayMetrics.density)

    private fun guessFileName(url: String?, disposition: String?, mime: String?): String {
        val cd = disposition.orEmpty()
        Regex("filename\\*?=(?:UTF-8''|\\\")?([^;\\\"]+)", RegexOption.IGNORE_CASE).find(cd)?.groupValues?.getOrNull(1)?.let {
            return java.net.URLDecoder.decode(it.trim().trim('\"'), "UTF-8")
        }
        val raw = runCatching { android.net.Uri.parse(url).lastPathSegment }.getOrNull().orEmpty()
        if (raw.isNotBlank()) return raw
        val ext = when (mime?.lowercase()) { "image/jpeg" -> "jpg"; "image/png" -> "png"; "image/webp" -> "webp"; "video/mp4" -> "mp4"; "audio/mpeg" -> "mp3"; else -> "" }
        return if (ext.isBlank()) "download" else "download.$ext"
    }
}
