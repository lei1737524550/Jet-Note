package leo.lei.note

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView

object NativeTopBar {
    const val HEIGHT_DP = UiTokens.TOP_BAR_HEIGHT_DP
    const val BUTTON_DP = UiTokens.TOP_BAR_BUTTON_DP
    private const val HORIZONTAL_MARGIN_DP = UiTokens.SPACE_L_DP.toFloat()
    private const val ICON_PADDING_DP = 7f
    private const val CORNER_RADIUS_DP = UiTokens.RADIUS_CONTROL_DP

    private fun dp(activity: Activity, value: Float) =
        (value * activity.resources.displayMetrics.density + 0.5f).toInt()

    fun build(
        activity: Activity,
        title: String,
        leftRes: Int? = R.drawable.jet_editor_close,
        rightRes: Int? = null,
        onLeft: (() -> Unit)? = { activity.finish() },
        onRight: (() -> Unit)? = null
    ): FrameLayout {
        val theme = ThemeStore.current(activity)
        val bar = FrameLayout(activity).apply {
            setBackgroundColor(theme.topColor)
            elevation = dp(activity, 1f).toFloat()
        }
        val titleView = TextView(activity).apply {
            text = title
            textSize = 17f
            setTextColor(theme.foregroundColor)
            gravity = Gravity.CENTER
        }
        bar.addView(
            titleView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER)
        )

        fun createButton(iconRes: Int, action: (() -> Unit)?): ImageButton = ImageButton(activity).apply {
            setImageResource(iconRes)
            scaleType = ImageView.ScaleType.CENTER
            setPadding(dp(activity, ICON_PADDING_DP), dp(activity, ICON_PADDING_DP), dp(activity, ICON_PADDING_DP), dp(activity, ICON_PADDING_DP))
            imageTintList = ColorStateList.valueOf(theme.foregroundColor)
            background = GradientDrawable().apply {
                setColor(theme.bodyColor)
                setStroke(dp(activity, 1f), if (theme == ThemeStore.Theme.DARK) 0xFF55575D.toInt() else 0xFFD0D1D5.toInt())
                cornerRadius = dp(activity, CORNER_RADIUS_DP).toFloat()
            }
            setOnClickListener { action?.invoke() }
        }

        leftRes?.let { iconRes ->
            bar.addView(
                createButton(iconRes, onLeft),
                FrameLayout.LayoutParams(dp(activity, BUTTON_DP.toFloat()), dp(activity, BUTTON_DP.toFloat()), Gravity.START or Gravity.CENTER_VERTICAL).apply {
                    marginStart = dp(activity, HORIZONTAL_MARGIN_DP)
                }
            )
        }
        rightRes?.let { iconRes ->
            bar.addView(
                createButton(iconRes, onRight),
                FrameLayout.LayoutParams(dp(activity, BUTTON_DP.toFloat()), dp(activity, BUTTON_DP.toFloat()), Gravity.END or Gravity.CENTER_VERTICAL).apply {
                    marginEnd = dp(activity, HORIZONTAL_MARGIN_DP)
                }
            )
        }
        bar.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, HEIGHT_DP.toFloat()))
        return bar
    }
}
