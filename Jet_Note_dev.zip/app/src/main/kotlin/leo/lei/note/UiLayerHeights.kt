package leo.lei.note

internal object UiLayerHeights {
    const val CONTENT = 0f
    const val MEDIA = 100f
    const val TOOL = 200f
    const val APP_OVERLAY = 300f
    const val TRANSITION = 1000f
}