package leo.lei.note

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class NativeSettingsActivity : Activity() {
    private lateinit var transitionTopBar: View
    private lateinit var transitionContent: View
    private var closing = false
    private lateinit var backup: BackupFileController
    private fun dp(value: Float) = UiTokens.dp(this, value)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeStore.applyWindow(this)
        val zh = UiLanguage.languageCode(this) == "zh"
        val theme = ThemeStore.current(this)
        backup = BackupFileController(this, NativePostRepository(this), AttachmentStore(this)) { }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(theme.topColor)
        }
        setContentView(root)
        SystemInsets.listen(root) { safe -> root.setPadding(0, safe.top, 0, safe.bottom) }

        val header = NativeTopBar.build(
            this,
            if (zh) "设置" else "Settings",
            leftRes = R.drawable.jet_editor_close,
            onLeft = { finishWithReverseAnimation() }
        )
        root.addView(header, LinearLayout.LayoutParams(-1, dp(UiTokens.TOP_BAR_HEIGHT_DP.toFloat())))
        transitionTopBar = header

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(theme.bodyColor)
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(UiTokens.SPACE_L_DP.toFloat()), dp(UiTokens.SPACE_L_DP.toFloat()), dp(UiTokens.SPACE_L_DP.toFloat()), dp(UiTokens.SPACE_XL_DP.toFloat()))
        }
        scroll.addView(content, FrameLayout.LayoutParams(-1, -2))
        transitionContent = content
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        sectionTitle(content, if (zh) "语言" else "Language", theme)
        content.addView(settingRow(if (zh) "界面语言" else "Interface language", if (zh) "中文" else "English", theme) {
            val target = if (zh) "en" else "zh"
            UiLanguage.setLanguageCode(this, target)
            setResult(RESULT_OK, Intent().putExtra(EXTRA_ACTION, ACTION_LANGUAGE).putExtra(EXTRA_LANGUAGE, target))
            recreate()
        })

        sectionTitle(content, if (zh) "主题" else "Theme", theme)
        val mode = ThemeStore.mode(this)
        content.addView(settingRow(if (zh) "跟随系统" else "Follow system", if (mode == ThemeStore.Mode.SYSTEM) "✓" else "", theme) {
            ThemeStore.setMode(this, "system"); finishThemeChange()
        })
        content.addView(settingRow(if (zh) "亮色" else "Light", if (mode == ThemeStore.Mode.CUSTOM && theme.id == "light") "✓" else "", theme) {
            ThemeStore.setMode(this, "custom"); ThemeStore.set(this, "light"); finishThemeChange()
        })
        content.addView(settingRow(if (zh) "暗色" else "Dark", if (mode == ThemeStore.Mode.CUSTOM && theme.id == "dark") "✓" else "", theme) {
            ThemeStore.setMode(this, "custom"); ThemeStore.set(this, "dark"); finishThemeChange()
        })
        content.addView(settingRow(if (zh) "绿色" else "Green", if (mode == ThemeStore.Mode.CUSTOM && theme.id == "green") "✓" else "", theme) {
            ThemeStore.setMode(this, "custom"); ThemeStore.set(this, "green"); finishThemeChange()
        })

        sectionTitle(content, if (zh) "导入 / 导出" else "Import / Export", theme)
        content.addView(settingRow(if (zh) "导出 .jnote" else "Export .jnote", "›", theme) { backup.exportArchive() })
        content.addView(settingRow(if (zh) "导入 .jnote" else "Import .jnote", "›", theme) { backup.chooseArchive() })

        
    }

    private fun sectionTitle(parent: LinearLayout, text: String, theme: ThemeStore.Theme) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = UiTokens.SECONDARY_SP
            setTextColor(theme.foregroundColor)
            alpha = 0.72f
            setPadding(dp(UiTokens.SPACE_XS_DP.toFloat()), dp(UiTokens.SPACE_L_DP.toFloat()), 0, dp(UiTokens.SPACE_S_DP.toFloat()))
        })
    }

    private fun settingRow(label: String, value: String, theme: ThemeStore.Theme, action: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(52f)
            setPadding(dp(UiTokens.SPACE_M_DP.toFloat()), 0, dp(UiTokens.SPACE_M_DP.toFloat()), 0)
            background = GradientDrawable().apply {
                setColor(theme.topColor)
                cornerRadius = dp(UiTokens.RADIUS_CONTROL_DP).toFloat()
            }
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        row.addView(TextView(this).apply {
            text = label
            textSize = 16f
            setTextColor(theme.foregroundColor)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(TextView(this).apply {
            text = value
            textSize = if (value == "✓") 18f else 20f
            setTextColor(theme.foregroundColor)
            alpha = if (value.isEmpty()) 0f else 0.72f
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            isSingleLine = true
            maxLines = 1
            minWidth = dp(88f)
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, -1))
        val params = LinearLayout.LayoutParams(-1, dp(52f))
        params.bottomMargin = dp(UiTokens.SPACE_S_DP.toFloat())
        row.layoutParams = params
        return row
    }

    private fun finishThemeChange() {
        setResult(RESULT_OK, Intent().putExtra(EXTRA_ACTION, ACTION_THEME))
        recreate()
    }

    private fun returnAction(action: String) {
        setResult(RESULT_OK, Intent().putExtra(EXTRA_ACTION, action))
        finishWithReverseAnimation()
    }

    private fun finishWithReverseAnimation() {
        if (closing) return
        if (!::transitionTopBar.isInitialized || !::transitionContent.isInitialized) { finish(); return }
        closing = true
        PageActivityTransition.finish(this)
    }


    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (::backup.isInitialized && backup.handles(requestCode)) {
            backup.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onDestroy() {
        if (::backup.isInitialized) backup.destroy()
        super.onDestroy()
    }

    override fun onBackPressed() = finishWithReverseAnimation()

    companion object {
        const val REQUEST_CODE = 4107
        const val EXTRA_ACTION = "jetnote.settings.action"
        const val EXTRA_LANGUAGE = "jetnote.settings.language"
        const val EXTRA_THEME = "jetnote.settings.theme"
        const val ACTION_EXPORT = "export"
        const val ACTION_IMPORT = "import"
        const val ACTION_LANGUAGE = "language"
        const val ACTION_THEME = "theme"
    }
}
