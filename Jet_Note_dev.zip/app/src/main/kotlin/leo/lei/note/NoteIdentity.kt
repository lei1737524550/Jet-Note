package leo.lei.note

import java.util.UUID

internal object NoteIdentity {
    fun create(): String = UUID.randomUUID().toString()
}
