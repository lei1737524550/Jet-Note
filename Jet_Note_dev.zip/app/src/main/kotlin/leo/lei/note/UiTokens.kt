package leo.lei.note

import android.content.Context

object UiTokens {
    const val TOP_BAR_HEIGHT_DP = 64
    const val TOP_BAR_BUTTON_DP = 42
    const val RADIUS_SMALL_DP = 10f
    const val RADIUS_CONTROL_DP = 14f
    const val RADIUS_CARD_DP = 18f
    const val TITLE_SP = 28f
    const val BODY_SP = 17f
    const val SECONDARY_SP = 14f
    const val SPACE_XS_DP = 4
    const val SPACE_S_DP = 8
    const val SPACE_M_DP = 12
    const val SPACE_L_DP = 16
    const val SPACE_XL_DP = 24

    fun dp(context: Context, value: Float): Int =
        (value * context.resources.displayMetrics.density + 0.5f).toInt()
}
