package leo.lei.note

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

internal object PostRules {
    private const val NONE = "none"
    private const val STAR = "star"
    private const val SUPER_STAR = "super_star"

    fun normalizeStarState(value: String?): String = when (value) {
        SUPER_STAR -> SUPER_STAR
        STAR -> STAR
        else -> NONE
    }

    fun normalizeRecord(source: JSONObject): JSONObject = copy(source).apply {
        put("starState", normalizeStarState(optString("starState", NONE)))
    }

    fun enforceSingleSuperStar(source: JSONArray): JSONArray {
        val list = MutableList(source.length()) { normalizeRecord(source.optJSONObject(it) ?: JSONObject()) }
        val supers = list.filter { starState(it) == SUPER_STAR }
        if (supers.size > 1) {
            val winner = supers.maxWithOrNull(compareBy<JSONObject> { score(it) })
            list.forEach { if (it !== winner && starState(it) == SUPER_STAR) it.put("starState", NONE) }
        }
        return JSONArray().also { out -> list.forEach(out::put) }
    }

    fun starState(post: JSONObject?): String = normalizeStarState(post?.optString("starState", NONE))

    fun publishedAt(post: JSONObject?): Long {
        if (post == null) return 0L
        parseTime(post.optString("createdAt", ""))?.let { return it }
        return post.optString("id", "").toLongOrNull() ?: 0L
    }

    fun compareDisplay(a: JSONObject?, b: JSONObject?): Int {
        val time = publishedAt(b).compareTo(publishedAt(a))
        return if (time != 0) time else id(b).compareTo(id(a))
    }

    fun compareFavorite(a: JSONObject?, b: JSONObject?): Int {
        val at = parseTime(a?.optString("favoritedAt", "") ?: "")
        val bt = parseTime(b?.optString("favoritedAt", "") ?: "")
        if (at != null && bt != null && at != bt) return bt.compareTo(at)
        if ((at != null) != (bt != null)) return if (at != null) -1 else 1
        return compareDisplay(a, b)
    }

    fun orderedMainPosts(source: JSONArray, mainPosts: Boolean, starPost: Boolean): JSONArray {
        if (!mainPosts) return JSONArray()
        val visible = source.objects().filter { starState(it) != SUPER_STAR }
        val regular = visible.filter { starState(it) != STAR }.sortedWith(Comparator { a, b -> compareDisplay(a, b) })
        val starred = if (starPost) visible.filter { starState(it) == STAR }.sortedWith(Comparator { a, b -> compareFavorite(a, b) }) else emptyList()
        return JSONArray().also { out -> (starred + regular).forEach(out::put) }
    }

    fun setArchived(post: Post, archived: Boolean): Post = post.copy(archived = archived)

    fun changeStar(posts: MutableList<Post>, targetId: String, requested: StarState?, now: String): StarState? {
        val index = posts.indexOfFirst { it.id == targetId }
        if (index < 0) return null
        val current = posts[index]
        val next = when (requested) {
            StarState.SUPER_STAR -> StarState.SUPER_STAR
            else -> if (current.starState == StarState.NONE) StarState.STAR else StarState.NONE
        }
        if (next == StarState.SUPER_STAR) {
            posts.indices.forEach { i ->
                if (i != index && posts[i].starState == StarState.SUPER_STAR) posts[i] = posts[i].copy(starState = StarState.NONE)
            }
        }
        posts[index] = current.copy(
            starState = next,
            favoritedAt = if (next == StarState.STAR && current.starState != StarState.STAR) now else current.favoritedAt
        )
        return next
    }

    fun changeStar(source: JSONArray, targetId: String, action: String, now: String): JSONObject? {
        val posts = source.objects().map(PostCodec::decode).toMutableList()
        val previous = posts.firstOrNull { it.id == targetId }?.starState ?: return null
        val requested = if (action == SUPER_STAR) StarState.SUPER_STAR else null
        val state = changeStar(posts, targetId, requested, now) ?: return null
        val movement = when {
            action == SUPER_STAR -> SUPER_STAR
            state == StarState.STAR -> STAR
            previous == StarState.SUPER_STAR -> "cancel_super_star"
            else -> "cancel_star"
        }
        return JSONObject().put("posts", JSONArray().also { out -> posts.forEach { out.put(PostCodec.encode(it)) } })
            .put("state", state.wireValue).put("movement", movement)
    }

    private fun setStar(post: JSONObject, state: String, now: String) {
        val previous = starState(post)
        val normalized = normalizeStarState(state)
        post.put("starState", normalized)
        if (normalized == STAR && previous != STAR) post.put("favoritedAt", now)
    }

    private fun score(post: JSONObject): Long = parseTime(post.optString("updatedAt", ""))
        ?: parseTime(post.optString("createdAt", ""))
        ?: post.optString("id", "").toLongOrNull() ?: 0L

    private fun parseTime(value: String): Long? = try { Instant.parse(value).toEpochMilli() } catch (_: Exception) { null }
    private fun id(post: JSONObject?): String = post?.opt("id")?.toString() ?: ""
    private fun copy(source: JSONObject): JSONObject = JSONObject(source.toString())
    private fun JSONArray.objects(): List<JSONObject> = List(length()) { optJSONObject(it) ?: JSONObject() }
}
