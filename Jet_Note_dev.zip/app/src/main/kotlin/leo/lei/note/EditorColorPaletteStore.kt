package leo.lei.note

import android.content.Context
import android.graphics.Color

internal object EditorColorPaletteStore {
    private const val PREFS = "jet_note_editor_palette"
    private val defaults = intArrayOf(
        Color.RED, 0xFFFF9800.toInt(), 0xFFFFD600.toInt(), 0xFF00A651.toInt(),
        0xFF2196F3.toInt(), 0xFF9C27B0.toInt(), 0xFF795548.toInt()
    )
    fun colors(context: Context): IntArray {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return IntArray(7) { i -> p.getInt("slot_$i", defaults[i]) }
    }
    fun set(context: Context, index: Int, color: Int) {
        if (index !in 0..6) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("slot_$index", color).apply()
    }
}
