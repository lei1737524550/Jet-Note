package leo.lei.note

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.DashPathEffect
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*
import org.json.JSONObject
import java.io.File
import kotlin.math.roundToInt
import kotlin.math.abs
import android.animation.TimeInterpolator
import android.view.animation.DecelerateInterpolator

class MainActivity : Activity() {
    private lateinit var repo: NativePostRepository
    private lateinit var list: LinearLayout
    private lateinit var root: LinearLayout
    private lateinit var titleBar: FrameLayout
    private lateinit var scroll: ScrollView
    private var composerBar: View? = null
    private var composerArchiveButton: ImageButton? = null
    private var floatingHomeMenu: LinearLayout? = null
    private lateinit var sounds: UiSoundPlayer
    private lateinit var backup: BackupFileController
    private var archiveMode=false
    private var appliedThemeId: String = ""
    private val expandedPostIds = mutableSetOf<String>()
    private val reorderInterpolator: TimeInterpolator = DecelerateInterpolator(1.35f)
    private val ui by lazy { LegacyUiMetrics(this) }
    private fun px(v:Float)=ui.px(v); private fun sp(v:Float)=ui.sp(v)
    private fun zh()=UiLanguage.languageCode(this)=="zh"
    private fun t(a:String,b:String)=if(zh())a else b

    override fun onCreate(b:Bundle?){ super.onCreate(b); repo=NativePostRepository(this); sounds=UiSoundPlayer(this); backup=BackupFileController(this,repo,AttachmentStore(this)){render()}; appliedThemeId=ThemeStore.current(this).id; applyBars(); setContentView(build()); setupFloatingMenu(); render() }
    override fun onDestroy(){ if(::backup.isInitialized) backup.destroy(); if(::sounds.isInitialized) sounds.release(); super.onDestroy() }
    override fun onResume(){
        super.onResume()
        val now=ThemeStore.current(this).id
        if(appliedThemeId.isNotEmpty() && now!=appliedThemeId){ recreate(); return }
        applyBars()
        if(::root.isInitialized){
            val th=ThemeStore.current(this)
            root.setBackgroundColor(th.topColor); scroll.setBackgroundColor(th.topColor); list.setBackgroundColor(th.topColor)
        }
        if(::list.isInitialized && repo.hasNativeData()) render()
    }
    private fun applyBars(){ ThemeStore.applyWindow(this) }
    private fun bg(fill:Int,stroke:Int,r:Float)=GradientDrawable().apply{setColor(fill);setStroke(px(1f),stroke);cornerRadius=px(r).toFloat()}

    private fun build():View{
        val th=ThemeStore.current(this); root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(th.topColor);fitsSystemWindows=true}
        titleBar=FrameLayout(this).apply{setBackgroundColor(th.topColor)}; root.addView(titleBar,LinearLayout.LayoutParams(-1,px(66f)))
        scroll=ScrollView(this).apply{isVerticalScrollBarEnabled=false;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS;setBackgroundColor(th.topColor)}
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(th.topColor);setPadding(px(6f),px(8f),px(6f),px(28f))};scroll.addView(list,FrameLayout.LayoutParams(-1,-2));root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); buildTop();return root
    }
    private fun buildTop(){
        titleBar.removeAllViews(); val th=ThemeStore.current(this); val stroke=if(th==ThemeStore.Theme.DARK)0xFFD8D8DE.toInt() else 0xFF343434.toInt()
        if(archiveMode){
            titleBar.visibility=View.VISIBLE; titleBar.layoutParams.height=px(NativeTopBar.HEIGHT_DP.toFloat()); titleBar.requestLayout(); composerBar=null
            val shared = NativeTopBar.build(
                this, t("归档","Archive"),
                leftRes = R.drawable.jet_editor_close,
                onLeft = { closeArchive() }
            )
            titleBar.addView(shared, FrameLayout.LayoutParams(-1,-1))
            floatingHomeMenu?.visibility=View.GONE; return
        }
        titleBar.visibility=View.GONE; titleBar.layoutParams.height=0; titleBar.requestLayout()
        composerBar=makeComposerBar(th,stroke)
    }
    private fun openArchive(){
        if(archiveMode) return
        archiveMode=true
        buildTop()
        render()
        NativePageEnterAnimation.play(titleBar, scroll, NativePageEnterAnimation.ContentFrom.LEFT, 200L)
    }
    private var archiveClosing = false
    private fun closeArchive(){
        if(!archiveMode || archiveClosing) return
        archiveClosing = true
        NativePageEnterAnimation.playExit(titleBar, scroll, NativePageEnterAnimation.ContentFrom.LEFT, 200L) {
            archiveMode=false
            archiveClosing=false
            titleBar.translationY=0f
            scroll.translationX=0f
            buildTop()
            render()
        }
    }

    override fun onBackPressed(){
        if(archiveMode){ closeArchive(); return }
        super.onBackPressed()
    }
    private fun makeComposerBar(th:ThemeStore.Theme, stroke:Int):View{
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=bg(th.bodyColor,stroke,14f);setPadding(px(12f),0,px(6f),0);tag="__composer__"}
        val prompt=TextView(this).apply{text=t("写点什么……","Write something...");textSize=sp(20f);setTextColor(th.foregroundColor);gravity=Gravity.CENTER_VERTICAL;setOnClickListener{openEditor(null)}};bar.addView(prompt,LinearLayout.LayoutParams(0,-1,1f))
        fun icon(res:Int,desc:String,act:()->Unit)=ImageButton(this).apply{setImageResource(res);contentDescription=desc;background=null;scaleType=ImageView.ScaleType.CENTER_INSIDE;setPadding(px(3f),px(3f),px(3f),px(3f));imageTintList=ColorStateList.valueOf(th.foregroundColor);setOnClickListener{act()}}
        bar.addView(icon(R.drawable.jet_menu_edit,t("创作","Create")){openEditor(null)},LinearLayout.LayoutParams(px(52f),-1))
        val archiveButton=icon(R.drawable.jet_menu_archive,t("归档","Archive")){openArchive()}
        composerArchiveButton=archiveButton
        bar.addView(archiveButton,LinearLayout.LayoutParams(px(52f),-1))
        bar.addView(icon(R.drawable.jet_settings_gear,t("设置","Settings")){startActivityForResult(Intent(this,NativeSettingsActivity::class.java),NativeSettingsActivity.REQUEST_CODE);overridePendingTransition(R.anim.page_enter_from_left, 0)},LinearLayout.LayoutParams(px(52f),-1))
        return bar
    }
    private fun setupFloatingMenu(){
        val th=ThemeStore.current(this)
        val stroke=if(th==ThemeStore.Theme.DARK)0xFFD8D8DE.toInt() else 0xFF343434.toInt()
        val row=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER
            background=bg(th.bodyColor,stroke,14f)
            visibility=View.GONE
        }
        fun add(res:Int, desc:String, act:()->Unit){
            row.addView(menuButton(res,th.foregroundColor,act).apply{contentDescription=desc},LinearLayout.LayoutParams(px(48f),px(48f)))
        }
        add(R.drawable.jet_menu_edit,t("创作","Create")){openEditor(null)}
        add(R.drawable.jet_menu_archive,t("归档","Archive")){openArchive()}
        add(R.drawable.jet_settings_gear,t("设置","Settings")){startActivityForResult(Intent(this,NativeSettingsActivity::class.java),NativeSettingsActivity.REQUEST_CODE);overridePendingTransition(R.anim.page_enter_from_left, 0)}
        floatingHomeMenu=row
        addContentView(row,ViewGroup.LayoutParams(px(144f),px(48f)))
        row.post{
            // Collapsed composer lives at the lower-left, aligned to the feed inset.
            row.x=px(8f).toFloat()
            positionFloating(row)
        }
        scroll.viewTreeObserver.addOnScrollChangedListener{updateFloatingVisibility()}
    }
    private fun positionFloating(v:View){
        val bottomInset = window.decorView.rootWindowInsets?.systemWindowInsetBottom.orZero()
        v.x = px(8f).toFloat()
        v.y = (resources.displayMetrics.heightPixels - bottomInset - px(48f) - px(16f)).toFloat()
    }
    private fun Int?.orZero()=this?:0
    private fun updateFloatingVisibility(){
        val c=composerBar
        if(archiveMode || c==null){floatingHomeMenu?.visibility=View.GONE;return}
        val xy=IntArray(2)
        c.getLocationOnScreen(xy)
        // Collapse as soon as any part of the composer is clipped above the visible feed.
        // The full composer starts at the scroll viewport's top when it is completely visible.
        val scrollXY=IntArray(2)
        scroll.getLocationOnScreen(scrollXY)
        val partiallyClipped = xy[1] < scrollXY[1]
        floatingHomeMenu?.visibility=if(partiallyClipped)View.VISIBLE else View.GONE
        floatingHomeMenu?.let{positionFloating(it)}
    }
    private fun showFloatingHomeMenu(anchor:View){
        val th=ThemeStore.current(this);val stroke=if(th==ThemeStore.Theme.DARK)0xFFD8D8DE.toInt() else 0xFF343434.toInt();val pop=PopupWindow(this)
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;background=bg(th.bodyColor,stroke,12f)}
        fun add(res:Int,act:()->Unit){row.addView(menuButton(res,th.foregroundColor){pop.dismiss();act()},LinearLayout.LayoutParams(px(48f),px(48f)))}
        add(R.drawable.jet_menu_edit){openEditor(null)}
        add(R.drawable.jet_menu_archive){openArchive()}
        add(R.drawable.jet_settings_gear){startActivityForResult(Intent(this,NativeSettingsActivity::class.java),NativeSettingsActivity.REQUEST_CODE);overridePendingTransition(R.anim.page_enter_from_left, 0)}
        pop.contentView=row;pop.width=px(144f);pop.height=px(48f);pop.isOutsideTouchable=true;pop.isFocusable=true;pop.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));pop.elevation=0f
        val xy=IntArray(2);anchor.getLocationOnScreen(xy);pop.showAtLocation(root,Gravity.TOP or Gravity.START,xy[0]-px(96f),xy[1]-px(54f))
    }
    /**
     * Home and Archive intentionally share one feed renderer.
     * Archive differs only by its top bar, archived-data filter, and the absence
     * of the composer. Keeping card grouping/layout here prevents the two pages
     * from drifting visually or behaviorally.
     */
    private fun render(){
        list.removeAllViews()
        val posts=repo.all()
            .filter{it.optBoolean("archived",false)==archiveMode}
            .sortedWith(postDisplayComparator())

        if(!archiveMode) attachComposer()
        if(posts.isEmpty()){
            showEmptyFeed()
            updateFloatingVisibility()
            return
        }

        renderPostFeed(posts)
        list.post{updateFloatingVisibility()}
    }

    private fun postDisplayComparator()=Comparator<JSONObject>{a,b->
        val sa=PostRules.starState(a); val sb=PostRules.starState(b)
        fun rank(v:String)=when(v){"super_star"->0;"star"->1;else->2}
        val r=rank(sa)-rank(sb)
        if(r!=0) r else if(sa=="star") PostRules.compareFavorite(a,b) else PostRules.compareDisplay(a,b)
    }

    private fun attachComposer(){
        composerBar?.let{
            (it.parent as? ViewGroup)?.removeView(it)
            list.addView(it,LinearLayout.LayoutParams(-1,px(UiTokens.TOP_BAR_HEIGHT_DP.toFloat())).apply{bottomMargin=px(8f)})
        }
    }

    private fun showEmptyFeed(){
        list.addView(TextView(this).apply{
            text=t(if(archiveMode) "暂无归档" else "暂无笔记",if(archiveMode) "No archived posts" else "No posts")
            gravity=Gravity.CENTER
            textSize=sp(16f)
            setTextColor(ThemeStore.current(this@MainActivity).foregroundColor)
            setPadding(0,px(60f),0,0)
        })
    }

    /** The exact same post presentation is used by Home and Archive. */
    private fun renderPostFeed(posts:List<JSONObject>){
        val superPosts=posts.filter{PostRules.starState(it)=="super_star"}
        val normalPosts=posts.filter{PostRules.starState(it)!="super_star"}
        superPosts.forEach{p->
            list.addView(singleGroup(p),LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=px(8f)})
        }
        if(normalPosts.isNotEmpty()) list.addView(postGroup(normalPosts))
    }

    private fun singleGroup(p:JSONObject):View{
        val th=ThemeStore.current(this); val stroke=if(th==ThemeStore.Theme.DARK)0xFFD8D8DE.toInt() else 0xFF2D2D2D.toInt()
        return FrameLayout(this).apply{
            background=bg(th.bodyColor,stroke,14f)
            addView(card(p,false,false),FrameLayout.LayoutParams(-1,-2))
        }
    }

    private fun postGroup(posts:List<JSONObject>):View{
        val th=ThemeStore.current(this); val stroke=if(th==ThemeStore.Theme.DARK)0xFFD8D8DE.toInt() else 0xFF2D2D2D.toInt()
        return LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            background=bg(th.bodyColor,stroke,14f)
            posts.forEachIndexed{index,p->
                if(index>0) addView(View(this@MainActivity).apply{setBackgroundColor(stroke)},LinearLayout.LayoutParams(-1,px(1f)))
                addView(card(p,false,true),LinearLayout.LayoutParams(-1,-2))
            }
        }
    }

    private fun card(p:JSONObject, compact:Boolean=false, grouped:Boolean=false):View{
        val th=ThemeStore.current(this)
        val id=p.opt("id")?.toString().orEmpty()
        val expanded=expandedPostIds.contains(id)
        val box=LinearLayout(this).apply{
            tag = "post:$id"
            orientation=LinearLayout.VERTICAL
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(px(12f),px(12f),px(12f),px(if(compact)12f else 14f))
        }
        val head=FrameLayout(this)
        val title=TextView(this).apply{
            text=p.optString("title"); textSize=sp(30f); setTextColor(th.foregroundColor)
            setTypeface(typeface,android.graphics.Typeface.BOLD)
            visibility=if(text.isBlank())View.GONE else View.VISIBLE
            maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END
        }
        head.addView(title,FrameLayout.LayoutParams(-1,px(32f),Gravity.START).apply{marginEnd=px(112f)})
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val state=PostRules.starState(p)
        if(state=="star" || state=="super_star"){
            val star=ImageButton(this).apply{
                setImageResource(if(state=="super_star")R.drawable.jet_archive_super_star else R.drawable.jet_archive_star)
                background=null; scaleType=ImageView.ScaleType.CENTER_INSIDE; setPadding(px(3f),px(3f),px(3f),px(3f))
                contentDescription=t("取消收藏","Remove favorite")
                setOnClickListener{
                    sounds.play(UiSoundPlayer.Cue.CANCEL_STAR)
                    // Immediate visual acknowledgement: do not make the icon wait for
                    // SharedPreferences serialization + full feed reconstruction.
                    setImageResource(R.drawable.jet_menu_star)
                    imageTintList=ColorStateList.valueOf(th.foregroundColor)
                    isEnabled=false
                    post { animateMutation(id,3600f){repo.toggleStar(id)} }
                }
            }
            actions.addView(star,LinearLayout.LayoutParams(px(38f),px(38f)).apply{marginEnd=px(12f)})
        }
        var expandButton:ImageButton?=null
        if(!compact){
            expandButton=ImageButton(this).apply{
                setImageResource(if(expanded)R.drawable.jet_post_collapse else R.drawable.jet_post_expand)
                imageTintList=ColorStateList.valueOf(th.foregroundColor); background=null; scaleType=ImageView.ScaleType.CENTER_INSIDE
                setPadding(px(3f),px(3f),px(3f),px(3f)); visibility=View.GONE
                contentDescription=t(if(expanded)"收起" else "展开",if(expanded)"Collapse" else "Expand")
            }
            actions.addView(expandButton,LinearLayout.LayoutParams(px(32f),px(32f)).apply{marginEnd=px(8f)})
        }
        val more=ImageButton(this).apply{
            setImageResource(R.drawable.jet_archive_more); imageTintList=ColorStateList.valueOf(th.foregroundColor); background=null; contentDescription=t("更多","More")
            scaleType=ImageView.ScaleType.CENTER_INSIDE; setPadding(px(3f),px(3f),px(3f),px(3f)); setOnClickListener{showMenu(this,p)}
        }
        actions.addView(more,LinearLayout.LayoutParams(px(38f),px(38f)))
        head.addView(actions,FrameLayout.LayoutParams(-2,px(38f),Gravity.END or Gravity.TOP).apply{marginEnd=px(18f)})
        box.addView(head,LinearLayout.LayoutParams(-1,px(32f)))
        val body=TextView(this).apply{
            text=p.optString("text"); maxLines=if(compact)1 else if(expanded)Int.MAX_VALUE else 6
            ellipsize=if(compact || !expanded) android.text.TextUtils.TruncateAt.END else null
            textSize=sp(17f); setTextColor(th.foregroundColor); setLineSpacing(0f,1.35f)
            setPadding(0,if(title.visibility==View.GONE)0 else px(2f),0,0); setOnClickListener{openViewer(p)}
        }
        if(body.text.isNotBlank()){
            box.addView(body,LinearLayout.LayoutParams(-1,-2))
            if(!compact && expandButton!=null){
                val eb=expandButton
                body.post{
                    val probe=TextView(this).apply{
                        text=body.text; textSize=body.textSize/resources.displayMetrics.scaledDensity
                        typeface=body.typeface; setLineSpacing(0f,1.35f); maxLines=Int.MAX_VALUE
                    }
                    val w=body.width
                    if(w>0){
                        probe.measure(View.MeasureSpec.makeMeasureSpec(w,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED))
                        eb.visibility=if(probe.lineCount>6)View.VISIBLE else View.GONE
                    }
                }
                eb.setOnClickListener{
                    if(expandedPostIds.contains(id)) expandedPostIds.remove(id) else expandedPostIds.add(id)
                    render()
                }
            }
        }
        addImages(box,p)
        box.setOnClickListener{openViewer(p)}
        return box
    }
    private fun addImages(parent:LinearLayout,p:JSONObject){ val a=p.optJSONArray("attachments")?:return;var shown=0;for(i in 0 until a.length()){val o=a.optJSONObject(i)?:continue;if(o.optString("type")!="image")continue;val f=AttachmentStore(this).fileForArchivePath(o.optString("path"))?:continue;if(!f.isFile)continue;val iv=ImageView(this).apply{adjustViewBounds=true;scaleType=ImageView.ScaleType.FIT_START;BitmapLoader.decode(f,resources.displayMetrics.widthPixels,(resources.displayMetrics.heightPixels*0.65f).toInt())?.let(::setImageBitmap);setOnClickListener{startActivity(Intent(this@MainActivity,NativeImageViewerActivity::class.java).putExtra(NativeImageViewerActivity.EXTRA_FILE_PATH,f.absolutePath));overridePendingTransition(R.anim.page_enter_from_left, 0)}};parent.addView(iv,LinearLayout.LayoutParams(-1,-2).apply{topMargin=px(10f)});shown++}}

    private fun menuButton(res:Int, tint:Int?=null, act:()->Unit)=ImageButton(this).apply{
        setImageResource(res); background=null; scaleType=ImageView.ScaleType.CENTER_INSIDE; setPadding(px(8f),px(8f),px(8f),px(8f))
        tint?.let{imageTintList=ColorStateList.valueOf(it)}; setOnClickListener{act()}
    }
    private fun popupPosition(anchor:View,width:Int):Pair<Int,Int>{
        val xy=IntArray(2); anchor.getLocationOnScreen(xy)
        val gap=px(6f)
        val edge=px(8f)
        val screenWidth=resources.displayMetrics.widthPixels
        val rawX=xy[0]-width-gap
        val x=rawX.coerceIn(edge,(screenWidth-width-edge).coerceAtLeast(edge))
        return x to xy[1]
    }
    private fun popupDividerColor(th:ThemeStore.Theme)=when(th){
        ThemeStore.Theme.DARK -> Color.WHITE
        ThemeStore.Theme.GREEN -> th.topColor
        else -> Color.BLACK
    }
    private fun popupDivider(th:ThemeStore.Theme)=object:View(this){
        private val linePaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{
            color=popupDividerColor(th)
            strokeWidth=px(1f).toFloat()
            style=Paint.Style.STROKE
            pathEffect=DashPathEffect(floatArrayOf(px(4f).toFloat(),px(3f).toFloat()),0f)
        }
        override fun onDraw(canvas:Canvas){
            super.onDraw(canvas)
            val x=width/2f
            canvas.drawLine(x,0f,x,height.toFloat(),linePaint)
        }
    }
    private fun showMenu(anchor:View,p:JSONObject){
        val th=ThemeStore.current(this); val stroke=if(th==ThemeStore.Theme.DARK)0xFFD8D8DE.toInt() else 0xFF343434.toInt()
        val cell=px(58f); val divider=px(1f); val width=cell*4+divider*3; val height=cell
        val (x,y)=popupPosition(anchor,width)
        val pop=PopupWindow(this)
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;background=bg(th.bodyColor,stroke,12f)}
        val id=p.opt("id")?.toString()?:return
        var count=0
        fun separator(){ if(count>0) row.addView(popupDivider(th),LinearLayout.LayoutParams(divider,px(40f))) }
        fun add(res:Int,tint:Int?=th.foregroundColor,act:()->Unit){ separator(); row.addView(menuButton(res,tint){pop.dismiss();act()},LinearLayout.LayoutParams(cell,cell)); count++ }
        run {
            val was=p.optBoolean("archived")
            val archiveRes=if(was) R.drawable.jet_menu_archive_filled_yellow else R.drawable.jet_menu_archive
            val archiveTint=if(was) null else th.foregroundColor
            add(archiveRes,archiveTint){
                sounds.play(if(was)UiSoundPlayer.Cue.DELETE else UiSoundPlayer.Cue.ARCHIVE)
                if(!was) flashComposerArchive()
                animateMutation(id,3600f){repo.setArchived(id,!was)}
            }
        }
        val starRes=when(PostRules.starState(p)){"super_star"->R.drawable.jet_archive_super_star;"star"->R.drawable.jet_archive_star;else->R.drawable.jet_menu_star}
        val starTint=if(PostRules.starState(p)=="none")th.foregroundColor else null
        separator()
        lateinit var star: ImageButton
        star=menuButton(starRes,starTint){
            val old=PostRules.starState(p)
            val next=if(old=="none") "star" else "none"
            // Paint the known next state before persistence/reorder work begins.
            star.setImageResource(if(next=="star") R.drawable.jet_archive_star else R.drawable.jet_menu_star)
            star.imageTintList=if(next=="star") null else ColorStateList.valueOf(th.foregroundColor)
            star.isEnabled=false
            sounds.play(if(old=="none")UiSoundPlayer.Cue.STAR else UiSoundPlayer.Cue.CANCEL_STAR)
            pop.dismiss()
            star.post { animateMutation(id,3600f){repo.toggleStar(id)} }
        }
        star.setOnLongClickListener{
            star.setImageResource(R.drawable.jet_archive_super_star)
            star.imageTintList=null
            star.isEnabled=false
            sounds.play(UiSoundPlayer.Cue.SUPER_STAR)
            pop.dismiss()
            star.post { animateSuperStarMutation(id){repo.toggleStar(id,true)} }
            true
        }
        row.addView(star,LinearLayout.LayoutParams(cell,cell)); count++
        add(R.drawable.jet_menu_edit){openEditor(p)}
        add(R.drawable.jet_menu_trash,null){ sounds.play(UiSoundPlayer.Cue.STAR); showDeleteConfirmAt(x,y,width,id) }
        pop.contentView=row;pop.width=width;pop.height=height;pop.isOutsideTouchable=true;pop.isFocusable=true
        pop.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); pop.elevation=0f
        pop.showAtLocation(root,Gravity.TOP or Gravity.START,x,y)
    }
    private fun flashComposerArchive(){
        val button=composerArchiveButton ?: return
        button.imageTintList=ColorStateList.valueOf(0xFFE9FF00.toInt())
        button.postDelayed({
            if(!archiveMode && composerArchiveButton === button) {
                button.imageTintList=ColorStateList.valueOf(ThemeStore.current(this).foregroundColor)
            }
        },200L)
    }

    private fun showDeleteConfirmAt(menuX:Int,menuY:Int,menuWidth:Int,id:String){
        val th=ThemeStore.current(this); val stroke=if(th==ThemeStore.Theme.DARK)0xFFD8D8DE.toInt() else 0xFF343434.toInt()
        val cell=px(58f); val divider=px(1f); val width=cell*2+divider; val edge=px(8f); val screenWidth=resources.displayMetrics.widthPixels; val x=(menuX+menuWidth-width).coerceIn(edge,(screenWidth-width-edge).coerceAtLeast(edge))
        val pop=PopupWindow(this)
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;background=bg(th.bodyColor,stroke,12f)}
        row.addView(menuButton(R.drawable.jet_menu_close,th.foregroundColor){pop.dismiss()},LinearLayout.LayoutParams(cell,cell))
        row.addView(popupDivider(th),LinearLayout.LayoutParams(divider,px(40f)))
        row.addView(menuButton(R.drawable.jet_menu_trash_open,null){pop.dismiss();sounds.play(UiSoundPlayer.Cue.DELETE);animateMutation(id,null,320L){repo.delete(id)}},LinearLayout.LayoutParams(cell,cell))
        pop.contentView=row;pop.width=width;pop.height=cell;pop.isOutsideTouchable=true;pop.isFocusable=true
        pop.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));pop.elevation=0f
        pop.showAtLocation(root,Gravity.TOP or Gravity.START,x,menuY)
    }

    private fun animateSuperStarMutation(activeId:String, mutation:()->Unit){
        val before=postViews()[activeId]
        if(before==null || before.width<=0 || before.height<=0){ animateMutation(activeId,3600f,mutation=mutation); return }
        val first=capturePostY()
        val firstXY=IntArray(2);before.getLocationOnScreen(firstXY)
        val bitmap=Bitmap.createBitmap(before.width,before.height,Bitmap.Config.ARGB_8888).also{before.draw(Canvas(it))}
        val proxy=ImageView(this).apply{setImageBitmap(bitmap);scaleType=ImageView.ScaleType.FIT_XY;translationZ=px(20f).toFloat()}
        addContentView(proxy,ViewGroup.LayoutParams(before.width,before.height));proxy.x=firstXY[0].toFloat();proxy.y=firstXY[1].toFloat()
        mutation();render()
        list.viewTreeObserver.addOnPreDrawListener(object:ViewTreeObserver.OnPreDrawListener{
            override fun onPreDraw():Boolean{
                list.viewTreeObserver.removeOnPreDrawListener(this)
                val now=postViews(); val target=now[activeId]
                if(target==null){(proxy.parent as? ViewGroup)?.removeView(proxy);bitmap.recycle();return true}
                val lastXY=IntArray(2);target.getLocationOnScreen(lastXY);target.visibility=View.INVISIBLE
                val moves=ArrayList<Pair<View,Float>>()
                for((id,v) in now){if(id==activeId)continue;val fy=first[id]?:continue;val xy=IntArray(2);v.getLocationOnScreen(xy);val dy=fy-xy[1];if(abs(dy)>.5f)moves+=v to dy}
                val composer=composerBar
                moves.forEach{(v,dy)->v.translationY=dy;v.animate().translationY(0f).setDuration(150L).setInterpolator(reorderInterpolator).start()}
                proxy.animate().x(lastXY[0].toFloat()).y(lastXY[1].toFloat()).setDuration(150L).setInterpolator(reorderInterpolator).withEndAction{
                    target.visibility=View.VISIBLE;(proxy.parent as? ViewGroup)?.removeView(proxy);bitmap.recycle();composer?.translationY=0f
                }.start()
                return true
            }
        })
    }
    
    private fun postViews(): Map<String, View> {
        val out=LinkedHashMap<String,View>()
        fun walk(v:View){
            val value=v.tag as? String
            if(value?.startsWith("post:")==true) out[value.removePrefix("post:")]=v
            if(v is ViewGroup) for(i in 0 until v.childCount) walk(v.getChildAt(i))
        }
        walk(list); return out
    }
    private fun capturePostY(): Map<String,Float> = postViews().mapValues { (_,v) ->
        val xy=IntArray(2); v.getLocationOnScreen(xy); xy[1].toFloat()
    }
    private fun animateMutation(activeId:String, speedPxPerSecond:Float?=null, fixedDurationMs:Long?=null, mutation:()->Unit){
        val first=capturePostY()
        mutation()
        render()
        list.viewTreeObserver.addOnPreDrawListener(object:ViewTreeObserver.OnPreDrawListener{
            override fun onPreDraw():Boolean{
                list.viewTreeObserver.removeOnPreDrawListener(this)
                val now=postViews()
                val moves=ArrayList<Pair<View,Float>>()
                var activeDistance=0f
                var minDistance=Float.MAX_VALUE
                for((id,v) in now){
                    val fy=first[id]?:continue
                    val xy=IntArray(2);v.getLocationOnScreen(xy)
                    val dy=fy-xy[1]
                    if(abs(dy)>.5f){moves+=v to dy;minDistance=minOf(minDistance,abs(dy));if(id==activeId)activeDistance=abs(dy)}
                }
                val ref=if(activeDistance>0f)activeDistance else if(minDistance<Float.MAX_VALUE)minDistance else 0f
                val duration=(fixedDurationMs ?: if(speedPxPerSecond!=null && ref>0f) ((ref/speedPxPerSecond)*1000f).roundToInt().toLong() else 150L).coerceIn(70L,420L)
                moves.forEach{(v,dy)->
                    v.translationY=dy
                    v.animate().translationY(0f).setDuration(duration).setInterpolator(reorderInterpolator).start()
                }
                return true
            }
        })
    }

    private fun openViewer(p:JSONObject){startActivity(Intent(this,NativePostViewerActivity::class.java).putExtra(NativePostViewerActivity.EXTRA_POST_JSON,p.toString()));overridePendingTransition(R.anim.page_enter_from_left, 0)}
    private fun openEditor(p:JSONObject?){val i=Intent(this,NativeEditorActivity::class.java);p?.let{i.putExtra(NativeEditorActivity.EXTRA_POST_JSON,it.toString())};startActivityForResult(i,NativeEditorActivity.REQUEST_CODE);overridePendingTransition(R.anim.page_enter_from_left, 0)}
    @Deprecated("Deprecated in Android") override fun onActivityResult(r:Int,c:Int,d:Intent?){
        super.onActivityResult(r,c,d)
        if(::backup.isInitialized && backup.handles(r)){ backup.onActivityResult(r,c,d); return }
        if(r==NativeEditorActivity.REQUEST_CODE&&c==RESULT_OK){
            d?.getStringExtra(NativeEditorActivity.RESULT_POST_JSON)?.let{repo.upsert(JSONObject(it));render()}
        } else if(r==NativeSettingsActivity.REQUEST_CODE){
            if(c==RESULT_OK){
            }
            applyBars();buildTop();render()
        }
    }
}
