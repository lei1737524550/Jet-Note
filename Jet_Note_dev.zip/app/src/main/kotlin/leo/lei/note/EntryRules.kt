package leo.lei.note

import org.json.JSONArray
import org.json.JSONObject

internal object EntryRules {
    fun normalize(sourceJson: String, generatedUuid: String, generatedId: Long, nowIso: String): String {
        val result = PostRules.normalizeRecord(JSONObject(sourceJson))
        if (result.optString("uuid", "").isBlank()) result.put("uuid", generatedUuid)
        val id = result.opt("id")
        val validId = when (id) {
            is Int -> true
            is Long -> id in -(1L shl 53)..(1L shl 53)
            is Double -> id.isFinite() && id % 1.0 == 0.0 && kotlin.math.abs(id) <= 9007199254740991.0
            else -> false
        }
        if (!validId) result.put("id", generatedId)
        if (result.opt("attachments") !is JSONArray) result.put("attachments", JSONArray())
        if (result.opt("images") !is JSONArray) result.put("images", JSONArray())
        if (!result.has("createdAt")) result.put("createdAt", nowIso)
        if (!result.has("updatedAt")) result.put("updatedAt", result.opt("createdAt"))
        return result.toString()
    }
}
