package leo.lei.note

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.text.Editable
import android.text.style.*
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.MarginLayoutParams
import android.view.WindowInsets
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class NativeEditorActivity : Activity() {
    private fun finishWithReverseAnimation() {
        if (closing) return
        closing = true
        val token = currentFocus?.windowToken ?: if (::enterContent.isInitialized) enterContent.windowToken else null
        (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)?.hideSoftInputFromWindow(token, 0)
        currentFocus?.clearFocus()

        // Do not guess an IME delay. Wait until Android reports that the IME is actually gone,
        // then let the Activity window itself slide out so Home is revealed underneath.
        val decor = window.decorView
        val started = android.os.SystemClock.uptimeMillis()
        fun waitForIme() {
            val visible = if (Build.VERSION.SDK_INT >= 23) {
                decor.rootWindowInsets?.isVisible(WindowInsets.Type.ime()) == true
            } else false
            if (!visible || android.os.SystemClock.uptimeMillis() - started >= 350L) {
                PageActivityTransition.finish(this)
            } else decor.postDelayed({ waitForIme() }, 16L)
        }
        decor.post { waitForIme() }
    }

    override fun onBackPressed() = finishWithReverseAnimation()

    companion object {
        const val REQUEST_CODE = 4108
        const val EXTRA_POST_JSON = "post_json"
        const val RESULT_POST_JSON = "result_post_json"
        private const val PICK_IMAGE = 4111
        private const val PICK_VIDEO = 4112
        private const val PICK_AUDIO = 4113
    }

    private lateinit var store: AttachmentStore
    private lateinit var titleInput: EditText
    private lateinit var textInput: RichContentEditText
    private lateinit var attachmentList: LinearLayout
    private lateinit var toolRail: LinearLayout
    private var savedSelectionStart = 0
    private var savedSelectionEnd = 0
    private val attachments = mutableListOf<Attachment>()
    private val formattingState = EditorFormattingState()
    private val colorCommands get() = formattingState.colors
    private val styleCommands get() = formattingState.styles
    private val fontCommands get() = formattingState.fonts
    private var formatting = false
    private var beforeText = ""
    private val pendingInputStyles = linkedSetOf<String>()
    private var pendingInputColor: Int? = null
    private var pendingInputColorExplicit = false
    private val worker = Executors.newSingleThreadExecutor()
    private var sourcePost: JSONObject? = null
    private var busy = false
    private lateinit var enterTopBar: View
    private lateinit var enterContent: View
    private var closing = false

    private val legacy by lazy { LegacyUiMetrics(this) }
    private fun dp(v: Float) = legacy.px(v)
    private fun legacySp(v: Float) = legacy.sp(v)
    private fun zh() = UiLanguage.languageCode(this) == "zh"
    private fun label(zhText: String, enText: String) = if (zh()) zhText else enText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeStore.applyWindow(this)
        ThemeStore.current(this).also {
            window.statusBarColor = it.topColor
            window.navigationBarColor = it.bodyColor
            // Keep the editor window fully opaque while IME resize is animating.
            window.setBackgroundDrawable(ColorDrawable(it.bodyColor))
            window.decorView.setBackgroundColor(it.bodyColor)
        }
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        store = AttachmentStore(this)
        sourcePost = intent.getStringExtra(EXTRA_POST_JSON)?.let { runCatching { JSONObject(it) }.getOrNull() }
        sourcePost?.optJSONArray("attachments")?.let { a ->
            for (i in 0 until a.length()) a.optJSONObject(i)?.let { attachments += PostCodec.decodeAttachment(it) }
        }
        formattingState.load(sourcePost)
        setContentView(buildUi())
        loadSource()
        
    }

    private fun buildUi(): View {
        val theme = ThemeStore.current(this)
        val foreground = theme.foregroundColor
        val divider = if (theme == ThemeStore.Theme.DARK) Color.rgb(82, 84, 91) else Color.rgb(205, 206, 210)
        val controlBackground = theme.bodyColor

        fun roundedBackground(fill: Int, stroke: Int, radiusDp: Float): GradientDrawable =
            GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(fill)
                setStroke(dp(1f), stroke)
                cornerRadius = dp(radiusDp).toFloat()
            }

        fun iconControl(caption: String, action: () -> Unit): TextView = TextView(this).apply {
            text = caption
            textSize = legacySp(25f)
            setTextColor(foreground)
            gravity = Gravity.CENTER
            isFocusable = false
            isFocusableInTouchMode = false
            background = roundedBackground(controlBackground, divider, 14f)
            setOnClickListener { action() }
        }

        fun imageControl(drawableRes: Int, action: () -> Unit): ImageButton = ImageButton(this).apply {
            setImageResource(drawableRes)
            imageTintList = android.content.res.ColorStateList.valueOf(foreground)
            scaleType = ImageView.ScaleType.CENTER
            setPadding(dp(6f), dp(6f), dp(6f), dp(6f))
            isFocusable = false
            isFocusableInTouchMode = false
            background = roundedBackground(controlBackground, divider, 14f)
            setOnClickListener { action() }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // Children are fully opaque. Keeping the host transparent allows the previous
            // Activity to be revealed geometrically while these two surfaces slide out.
            setBackgroundColor(Color.TRANSPARENT)
        }
        val bar = NativeTopBar.build(
            this,
            if (sourcePost == null) label("新建笔记", "New Post") else label("编辑笔记", "Edit Post"),
            leftRes = R.drawable.jet_editor_close,
            rightRes = R.drawable.jet_editor_send,
            onLeft = { finishWithReverseAnimation() },
            onRight = { save() }
        )
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(NativeTopBar.HEIGHT_DP.toFloat())))
        enterTopBar = bar
        val editorCanvas = FrameLayout(this).apply { setBackgroundColor(theme.bodyColor) }
        root.addView(editorCanvas, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        enterContent = editorCanvas

        titleInput = EditText(this).apply {
            hint = label("标题", "Title")
            textSize = legacySp(30f)
            setTextColor(foreground)
            setHintTextColor(if (theme == ThemeStore.Theme.DARK) Color.LTGRAY else Color.GRAY)
            maxLines = 1
            setSingleLine(true)
            setPadding(0, 0, 0, 0)
            background = null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                textCursorDrawable = GradientDrawable().apply { setColor(foreground); setSize(dp(2f), dp(28f)) }
            }
        }
        editorCanvas.addView(titleInput, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44f), Gravity.TOP).apply {
            leftMargin = dp(20f); rightMargin = dp(20f); topMargin = dp(24f)
        })
        editorCanvas.addView(View(this).apply { setBackgroundColor(divider) }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1f), Gravity.TOP).apply {
            topMargin = dp(67f)
        })

        textInput = RichContentEditText(this).apply {
            hint = label("写点什么…", "Write something...")
            textSize = legacySp(25.5f)
            setTextColor(foreground)
            setHintTextColor(if (theme == ThemeStore.Theme.DARK) Color.LTGRAY else Color.GRAY)
            gravity = Gravity.TOP or Gravity.START
            setPadding(0, dp(8f), 0, dp(8f))
            background = null
            isVerticalScrollBarEnabled = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            setHorizontallyScrolling(false)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                textCursorDrawable = GradientDrawable().apply { setColor(foreground); setSize(dp(2f), dp(28f)) }
            }
        }
        editorCanvas.addView(textInput, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.TOP).apply {
            leftMargin = dp(20f); rightMargin = dp(20f); topMargin = dp(78f); bottomMargin = dp(88f)
        })
        bindFormattingTracking()
        textInput.onImageUri = { uri, release -> importImageUri(uri, release); true }

        toolRail = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            isFocusable = false
            isFocusableInTouchMode = false
        }
        showMainTools()
        editorCanvas.addView(toolRail, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48f), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(18f)
        })
        attachmentList = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        editorCanvas.addView(attachmentList, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54f), Gravity.BOTTOM).apply {
            leftMargin = dp(20f); rightMargin = dp(20f); bottomMargin = dp(70f)
        })

        SystemInsets.listen(root) { safe ->
            // adjustResize already owns IME sizing. Applying imeBottom here as well
            // double-resizes the editor and can expose the activity below for a frame.
            root.setPadding(0, safe.top, 0, safe.bottom)
        }
        return root
    }

    private fun loadSource() {
        sourcePost?.let {
            titleInput.setText(it.optString("title", ""))
            formatting = true
            textInput.setText(it.optString("text", ""))
            formatting = false
            beforeText = textInput.text.toString()
            applyFormattingPreview()
        }
        renderAttachments()
        textInput.requestFocus()
    }

    private fun choose(code: Int, mime: String) {
        if (busy) return
        val type = when (code) { PICK_IMAGE -> "image"; PICK_VIDEO -> "video"; else -> "audio" }
        val count = attachments.count { it.type == type }
        val visualCount = attachments.count { it.type == "image" || it.type == "video" }
        val blocked = (type == "audio" && count >= 1) || (type == "video" && count >= 3) || (type == "video" && visualCount >= 3)
        if (blocked) { Toast.makeText(this, label("已达到附件数量上限", "Attachment limit reached"), Toast.LENGTH_SHORT).show(); return }
        if (code == PICK_IMAGE) {
            val intent = if (Build.VERSION.SDK_INT >= 33) {
                Intent(MediaStore.ACTION_PICK_IMAGES).apply { this.type = "image/*" }
            } else {
                Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply { this.type = "image/*" }
            }
            startActivityForResult(intent, code)
        } else {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); this.type = mime }, code)
        }
    }

    private fun importImageUri(uri: Uri, releasePermission: (() -> Unit)? = null) {
        if (busy) return
        busy = true
        worker.execute {
            val result = runCatching { store.importFromUri(uri, "image") }
            releasePermission?.invoke()
            runOnUiThread {
                busy = false
                result.onSuccess { attachments += PostCodec.decodeAttachment(it); renderAttachments() }
                    .onFailure { Toast.makeText(this, label("图片读取失败", "Cannot read image"), Toast.LENGTH_SHORT).show() }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        if (requestCode == PICK_IMAGE) { importImageUri(uri); return }
        val type = when (requestCode) { PICK_VIDEO -> "video"; PICK_AUDIO -> "audio"; else -> return }
        busy = true
        worker.execute {
            val result = runCatching { store.importFromUri(uri, type) }
            runOnUiThread { busy = false; result.onSuccess { attachments += PostCodec.decodeAttachment(it); renderAttachments() } }
        }
    }

    private fun renderAttachments() {
        attachmentList.removeAllViews()
        val images = attachments.filter { it.type == "image" }
        if (images.isEmpty()) { attachmentList.visibility = View.GONE; return }
        attachmentList.visibility = View.VISIBLE
        images.forEach { item ->
            val fileName = item.path.removePrefix("media/")
            val file = java.io.File(store.mediaDirectory(), fileName)
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                BitmapLoader.decode(file, resources.displayMetrics.widthPixels, (resources.displayMetrics.heightPixels * 0.5f).toInt())?.let(::setImageBitmap)
                setOnLongClickListener { attachments.remove(item); renderAttachments(); true }
            }
            attachmentList.addView(iv, LinearLayout.LayoutParams(dp(52f), dp(52f)).apply { marginStart = dp(4f); marginEnd = dp(4f) })
        }
    }

    private fun save() {
        if (busy) return
        val text = textInput.text.toString()
        val title = titleInput.text.toString().trim()
        if (text.isBlank() && title.isBlank() && attachments.isEmpty()) {
            Toast.makeText(this, label("笔记内容不能为空", "Post content cannot be empty"), Toast.LENGTH_SHORT).show(); return
        }
        val result = JSONObject(sourcePost?.toString() ?: "{}")
        result.put("nativeEditorMode", if (sourcePost == null) "create" else "edit")
        result.put("text", text)
        result.put("title", title)
        result.put("attachments", JSONArray().apply { attachments.forEach { put(PostCodec.encodeAttachment(it)) } })
        result.put("images", JSONArray().apply { attachments.filter { it.type == "image" }.forEach { put(AttachmentStore.MEDIA_URL_PREFIX + it.path.removePrefix("media/")) } })
        formattingState.writeTo(result)
        setResult(RESULT_OK, Intent().putExtra(RESULT_POST_JSON, result.toString()))
        finishWithReverseAnimation()
    }


    private fun selection(): Pair<Int,Int>? {
        val a = textInput.selectionStart.coerceAtLeast(0); val b = textInput.selectionEnd.coerceAtLeast(0)
        val start=minOf(a,b); val end=maxOf(a,b)
        if (end<=start) { Toast.makeText(this,label("请先选择文字","Select text first"),Toast.LENGTH_SHORT).show(); return null }
        return start to end
    }

    private fun snapshotSelection() {
        savedSelectionStart = textInput.selectionStart.coerceAtLeast(0)
        savedSelectionEnd = textInput.selectionEnd.coerceAtLeast(0)
    }

    private fun restoreEditorSelection() {
        val n = textInput.length()
        textInput.requestFocus()
        textInput.setSelection(savedSelectionStart.coerceIn(0, n), savedSelectionEnd.coerceIn(0, n))
    }

    private fun toolButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; textSize = legacySp(18f)
        setTextColor(ThemeStore.current(this@NativeEditorActivity).foregroundColor)
        isFocusable = false; isFocusableInTouchMode = false; isClickable = true
        background = GradientDrawable().apply {
            setColor(ThemeStore.current(this@NativeEditorActivity).bodyColor)
            setStroke(dp(1f), if (ThemeStore.current(this@NativeEditorActivity) == ThemeStore.Theme.DARK) Color.DKGRAY else 0xFFCACBD0.toInt())
            cornerRadius = dp(10f).toFloat()
        }
        setOnTouchListener { _, e -> if (e.action == android.view.MotionEvent.ACTION_DOWN) snapshotSelection(); false }
        setOnClickListener { onClick(); restoreEditorSelection() }
    }

    private fun toolImage(drawable: Int, onClick: () -> Unit): ImageButton = ImageButton(this).apply {
        setImageResource(drawable); imageTintList = android.content.res.ColorStateList.valueOf(ThemeStore.current(this@NativeEditorActivity).foregroundColor); scaleType = ImageView.ScaleType.CENTER_INSIDE; setPadding(dp(7f),dp(7f),dp(7f),dp(7f))
        isFocusable = false; isFocusableInTouchMode = false; isClickable = true
        background = GradientDrawable().apply {
            setColor(ThemeStore.current(this@NativeEditorActivity).bodyColor)
            setStroke(dp(1f), if (ThemeStore.current(this@NativeEditorActivity) == ThemeStore.Theme.DARK) Color.DKGRAY else 0xFFCACBD0.toInt())
            cornerRadius = dp(10f).toFloat()
        }
        setOnTouchListener { _, e -> if (e.action == android.view.MotionEvent.ACTION_DOWN) snapshotSelection(); false }
        setOnClickListener { onClick(); restoreEditorSelection() }
    }

    private fun setToolRailHeight(heightDp: Float) {
        val lp = toolRail.layoutParams
        if (lp != null) { lp.height = dp(heightDp); toolRail.layoutParams = lp }
    }

    private fun describedTool(description: String, button: View, buttonDp: Float = 42f, selected: Boolean = false): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        isFocusable = false
        addView(TextView(this@NativeEditorActivity).apply {
            text = description
            textSize = legacySp(10f)
            gravity = Gravity.CENTER
            setTextColor(ThemeStore.current(this@NativeEditorActivity).foregroundColor)
            isSingleLine = true
            isFocusable = false
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(18f)))
        addView(button, LinearLayout.LayoutParams(dp(buttonDp), dp(buttonDp)))
        addView(TextView(this@NativeEditorActivity).apply {
            text = if (selected) "▲" else ""
            textSize = legacySp(9f)
            gravity = Gravity.CENTER
            includeFontPadding = false
            setTextColor(if (ThemeStore.current(this@NativeEditorActivity) == ThemeStore.Theme.DARK) Color.WHITE else Color.BLACK)
            isFocusable = false
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8f)))
    }

    private fun showMainTools() {
        if (!::toolRail.isInitialized) return
        toolRail.removeAllViews()
        setToolRailHeight(48f)
        val style = toolButton("𝑰") { showStyleTools() }
        val palette = toolImage(R.drawable.jet_editor_palette) { showColorTools() }
        val image = toolImage(R.drawable.jet_editor_photo) { choose(PICK_IMAGE, "image/*") }
        listOf(style, palette, image).forEach { v -> toolRail.addView(v, LinearLayout.LayoutParams(dp(48f), dp(48f)).apply { marginStart=dp(6f); marginEnd=dp(6f) }) }
    }

    private fun showStyleTools() {
        toolRail.removeAllViews()
        setToolRailHeight(74f)
        val defs = listOf(
            Triple("‹", "back", label("返回", "Back")),
            Triple("Tx", "clear", label("清除", "Clear")),
            Triple("B", "bold", label("粗体", "Bold")),
            Triple("I", "italic", label("斜体", "Italic")),
            Triple("U", "underline", label("下划线", "Underline")),
            Triple("S", "strike", label("删除线", "Strike")),
            Triple("T̅", "overline", label("上划线", "Overline"))
        )
        defs.forEach { (buttonLabel, key, description) ->
            val b = toolButton(buttonLabel) {
                if (key == "back") showMainTools() else {
                    applyStyleFromRail(key)
                    showStyleTools()
                }
            }
            if (key == "bold") b.setTypeface(null, Typeface.BOLD)
            if (key == "italic") b.setTypeface(null, Typeface.ITALIC)
            if (key == "underline") b.paintFlags = b.paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
            if (key == "strike") b.paintFlags = b.paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
            val selected = key != "back" && key != "clear" && pendingInputStyles.contains(key)
            toolRail.addView(describedTool(description, b, selected = selected), LinearLayout.LayoutParams(dp(48f), dp(74f)).apply { marginStart=dp(3f); marginEnd=dp(3f) })
        }
    }

    private fun showColorTools() {
        toolRail.removeAllViews()
        setToolRailHeight(72f)
        val colors = EditorColorPaletteStore.colors(this)
        val names = listOf(
            label("红色", "Red"), label("橙色", "Orange"), label("黄色", "Yellow"),
            label("绿色", "Green"), label("蓝色", "Blue"), label("紫色", "Purple"), label("棕色", "Brown")
        )
        fun addColor(color: Int?, description: String, isBack: Boolean = false) {
            val b = toolButton(if (isBack) "‹" else if (color == null) "D" else "") {
                if (isBack) showMainTools() else {
                    applyColorFromRail(color)
                    showColorTools()
                }
            }
            if (!isBack) b.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color ?: 0xFFE7E7E7.toInt())
                setStroke(dp(1f), 0xFFBFC1C4.toInt())
            }
            val selected = !isBack && pendingInputColorExplicit && pendingInputColor == color
            toolRail.addView(describedTool(description, b, 40f, selected), LinearLayout.LayoutParams(dp(44f), dp(72f)).apply { marginStart=dp(2f); marginEnd=dp(2f) })
        }
        addColor(null, label("返回", "Back"), true)
        addColor(null, label("默认", "Default"))
        colors.forEachIndexed { index, color -> addColor(color, names.getOrElse(index) { label("颜色", "Color") }) }
    }

    private fun currentSavedSelection(): Pair<Int,Int> {
        val start=minOf(savedSelectionStart,savedSelectionEnd); val end=maxOf(savedSelectionStart,savedSelectionEnd)
        return start to end
    }

    private fun applyColorFromRail(color: Int?) {
        val sel=currentSavedSelection()
        val hex=color?.let { String.format("#%06X", 0xFFFFFF and it) }
        if(sel.first==sel.second){
            pendingInputColor=color
            pendingInputColorExplicit=true
            colorCommands.removeAll { it.optInt("offset")==sel.first }
            colorCommands += JSONObject().put("offset",sel.first).put("color",hex ?: JSONObject.NULL)
            colorCommands.sortBy { it.optInt("offset") }
            return
        }
        val restore=colorCommands.lastOrNull { it.optInt("offset") <= sel.second }?.optString("color")?.takeIf{it.isNotBlank()}
        colorCommands.removeAll { it.optInt("offset") in sel.first until sel.second }
        colorCommands += JSONObject().put("offset",sel.first).put("color",hex ?: JSONObject.NULL)
        if(sel.second < textInput.length()) colorCommands += JSONObject().put("offset",sel.second).put("color",restore ?: JSONObject.NULL)
        colorCommands.sortBy { it.optInt("offset") }; applyFormattingPreview(sel)
    }

    private fun applyStyleFromRail(style: String) {
        val sel=currentSavedSelection()
        if(sel.first==sel.second){
            if(style=="clear"){
                pendingInputStyles.clear(); pendingInputColor=null; pendingInputColorExplicit=true
                colorCommands.removeAll { it.optInt("offset")==sel.first }
                colorCommands += JSONObject().put("offset",sel.first).put("color",JSONObject.NULL)
            } else if(!pendingInputStyles.add(style)) pendingInputStyles.remove(style)
            return
        }
        if(style=="clear") {
            styleCommands.removeAll { it.optInt("start") < sel.second && it.optInt("end") > sel.first }
            fontCommands.removeAll { it.optInt("start") < sel.second && it.optInt("end") > sel.first }
            colorCommands.removeAll { it.optInt("offset") in sel.first until sel.second }
        } else {
            val active=styleCommands.any{it.optString("style")==style && it.optInt("start")<=sel.first && it.optInt("end")>=sel.second}
            if(active) styleCommands.removeAll{it.optString("style")==style && it.optInt("start")<=sel.first && it.optInt("end")>=sel.second}
            else styleCommands += JSONObject().put("start",sel.first).put("end",sel.second).put("style",style)
        }
        applyFormattingPreview(sel)
    }

    private fun pickFont() {
        val sel=selection() ?: return
        val names=arrayOf(label("系统默认","System"),"Serif","Sans Serif","Monospace")
        val values=arrayOf("default","serif","sans","monospace")
        android.app.AlertDialog.Builder(this).setTitle(label("选择字体","Choose font")).setItems(names){_,which ->
            fontCommands.removeAll { it.optInt("start") < sel.second && it.optInt("end") > sel.first }
            if(values[which] != "default") fontCommands += JSONObject().put("start",sel.first).put("end",sel.second).put("font",values[which])
            applyFormattingPreview(sel)
        }.show()
    }

    private fun bindFormattingTracking() {
        beforeText=textInput.text.toString()
        textInput.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){ if(!formatting) beforeText=s?.toString().orEmpty() }
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){
                if(!formatting){
                    shiftCommands(start,before,count)
                    if(count>0 && before==0){
                        pendingInputStyles.forEach { styleCommands += JSONObject().put("start",start).put("end",start+count).put("style",it) }
                        if(pendingInputColorExplicit){
                            val hex=pendingInputColor?.let { String.format("#%06X",0xFFFFFF and it) }
                            colorCommands.removeAll { it.optInt("offset")==start }
                            colorCommands += JSONObject().put("offset",start).put("color",hex ?: JSONObject.NULL)
                            colorCommands.sortBy { it.optInt("offset") }
                        }
                    }
                }
            }
            override fun afterTextChanged(s:Editable?){ if(!formatting){ beforeText=s?.toString().orEmpty(); applyFormattingPreview() } }
        })
    }

    private fun shiftCommands(at:Int, removed:Int, added:Int) {
        val oldEnd=at+removed; val delta=added-removed
        colorCommands.removeAll { it.optInt("offset") in at until oldEnd }.also { colorCommands.forEach { if(it.optInt("offset")>=oldEnd) it.put("offset",it.optInt("offset")+delta) } }
        fun shiftRanges(list:MutableList<JSONObject>){
            val dead=mutableListOf<JSONObject>(); for(c in list){var a=c.optInt("start");var b=c.optInt("end"); if(b<=at){} else if(a>=oldEnd){a+=delta;b+=delta}else{b=(b+delta).coerceAtLeast(at); if(a>at)a=at; if(b<=a)dead+=c};c.put("start",a);c.put("end",b)};list.removeAll(dead)
        }
        shiftRanges(styleCommands); shiftRanges(fontCommands)
    }

    private fun applyFormattingPreview(restore:Pair<Int,Int>?=null) {
        if(formatting) return; formatting=true
        val raw=textInput.text.toString(); val ss=SpannableStringBuilder(raw); val n=raw.length
        fun range(c:JSONObject):Pair<Int,Int>? { val a=c.optInt("start").coerceIn(0,n);val b=c.optInt("end").coerceIn(0,n);return if(b>a)a to b else null }
        styleCommands.forEach { c -> range(c)?.let{(a,b)-> when(c.optString("style")){"bold"->ss.setSpan(StyleSpan(Typeface.BOLD),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);"italic"->ss.setSpan(StyleSpan(Typeface.ITALIC),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);"underline"->ss.setSpan(UnderlineSpan(),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);"strike"->ss.setSpan(StrikethroughSpan(),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);"overline"->ss.setSpan(OverlineSpan(),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)}} }
        fontCommands.forEach { c -> range(c)?.let{(a,b)-> val family=when(c.optString("font")){"serif"->"serif";"monospace"->"monospace";else->"sans-serif"};ss.setSpan(TypefaceSpan(family),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)} }
        val sorted=colorCommands.sortedBy{it.optInt("offset")}; for(i in sorted.indices){val c=sorted[i];val color=c.optString("color").takeIf{it.matches(Regex("#[0-9A-Fa-f]{6}"))}?:continue;val a=c.optInt("offset").coerceIn(0,n);val b=(sorted.getOrNull(i+1)?.optInt("offset")?:n).coerceIn(a,n);if(b>a)runCatching{ss.setSpan(ForegroundColorSpan(Color.parseColor(color)),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)}}
        val oldA=textInput.selectionStart.coerceAtLeast(0);val oldB=textInput.selectionEnd.coerceAtLeast(0); textInput.setText(ss); val r=restore ?: (oldA to oldB); textInput.setSelection(r.first.coerceIn(0,n),r.second.coerceIn(0,n)); formatting=false
    }

    override fun onDestroy() { worker.shutdownNow(); super.onDestroy() }
}
