package leo.lei.note

import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import java.io.File

internal object MediaMetadataReader {
    fun durationMs(file: File, mimeType: String?): Long? {
        if (mimeType?.startsWith("audio/") != true && mimeType?.startsWith("video/") != true) return null
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
        } catch (_: RuntimeException) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    fun dimensions(file: File, mimeType: String?): Pair<Int, Int> {
        if (mimeType?.startsWith("image/") == true) {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, options)
            return options.outWidth.coerceAtLeast(0) to options.outHeight.coerceAtLeast(0)
        }
        if (mimeType?.startsWith("video/") == true) {
            val retriever = MediaMetadataRetriever()
            return try {
                retriever.setDataSource(file.absolutePath)
                val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                width to height
            } catch (_: RuntimeException) {
                0 to 0
            } finally {
                runCatching { retriever.release() }
            }
        }
        return 0 to 0
    }
}
