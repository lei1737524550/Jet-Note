package leo.lei.note

import android.content.Context
import kotlin.math.roundToInt

internal class LegacyUiMetrics(private val context: Context) {
    companion object { const val LEGACY_PX_TO_PHYSICAL_PX = 2.65f }
    fun px(v: Float): Int = (v * LEGACY_PX_TO_PHYSICAL_PX).roundToInt()
    fun sp(v: Float): Float = (v * LEGACY_PX_TO_PHYSICAL_PX) / context.resources.displayMetrics.scaledDensity
}
