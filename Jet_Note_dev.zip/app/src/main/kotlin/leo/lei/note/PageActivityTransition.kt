package leo.lei.note

import android.app.Activity

/** Window-level page motion. Moving the Activity window lets Android reveal the previous Activity without transparent-surface artifacts. */
object PageActivityTransition {
    fun enter(activity: Activity) { activity.overridePendingTransition(R.anim.page_enter_from_left, 0) }
    fun finish(activity: Activity) {
        activity.finish()
        activity.overridePendingTransition(0, R.anim.page_exit_to_left)
    }
}
