package leo.lei.note

import android.content.Context
import org.json.JSONObject

internal object RuntimeConfigStore {
    private const val HARDCODED = "{\"global_set_background\":\"#AED194\",\"global_set_body\":\"#D2E9C2\",\"jet_scrollbar\":{\"visual_width_px\":7,\"interaction_width_px\":20},\"load_animation\":{\"load_animation_background\":\"#AED194\",\"load_animation_minimum_duration_ms\":300},\"three_post_one_body\":{\"top_post\":{\"super_star\":{\"time_stamp_color\":\"999da2\",\"time_stamp_top_margin\":10,\"time_stamp_bottom_margin\":3,\"border_rule\":{\"change_count\":0,\"sequence\":[{\"color\":\"#bfc1c4\",\"duration_ms\":1000}]}}},\"post_composer\":{\"border_rule\":{\"change_count\":0,\"sequence\":[{\"color\":\"#bfc1c4\",\"duration_ms\":1000}]}},\"main_posts\":{\"interaction_timing\":{\"post_delete_reflow_animation_duration_ms\":320,\"post_reflow_animation\":{\"speed_or_duration\":\"speed\",\"star\":{\"duration_ms\":150,\"speed_px_per_second\":3600},\"cancel_star\":{\"duration_ms\":150,\"speed_px_per_second\":3600},\"super_star\":{\"duration_ms\":150,\"speed_px_per_second\":3600},\"cancel_super_star\":{\"duration_ms\":150,\"speed_px_per_second\":3600}},\"post_star_highlight\":{\"inset_width_px\":2,\"display_delay_after_reflow_ms\":300,\"normal\":{\"change_count\":0,\"sequence\":[{\"color\":\"#ffff00\",\"duration_ms\":500}]},\"super\":{\"change_count\":0,\"sequence\":[{\"color\":\"#ff0000\",\"duration_ms\":500}]}},\"post_horizontal_ellipsis_menu_dismiss_delay_ms\":100,\"delete_content_to_border_clear_delay_ms\":140,\"delete_border_clear_to_reflow_delay_ms\":140},\"non_star\":{\"time_stamp_color\":\"999da2\",\"time_stamp_top_margin\":3,\"time_stamp_bottom_margin\":3,\"border_rule\":{\"change_count\":0,\"sequence\":[{\"color\":\"#bfc1c4\",\"duration_ms\":1000}]}},\"star\":{\"time_stamp_color\":\"999da2\",\"time_stamp_top_margin\":3,\"time_stamp_bottom_margin\":3,\"border_rule\":{\"change_count\":0,\"sequence\":[{\"color\":\"#bfc1c4\",\"duration_ms\":1000}]}}},\"surface_vertical_gap_px\":6},\"post_text_drawer_animation\":{\"duration_ms\":300},\"post_editor_text_caret\":{\"text_caret_visible_state_duration_ms\":750,\"text_caret_hidden_state_duration_ms\":750,\"text_caret_width_px\":2,\"text_caret_color\":\"#14A89A\"},\"shared_transition\":{\"duration_ms\":320},\"is_display\":{\"top_post\":true,\"post_composer\":true,\"main_posts\":true,\"star_post\":true},\"post_attachment\":{\"audio_max_quantity\":1,\"video_max_quantity\":3,\"photo_max_quantity\":3,\"video_photo_coexistence\":true,\"video_photo_combined_max_quantity\":3},\"videoPlayback\":{\"maxConcurrentPlayingVideos\":3},\"audioPlayback\":{\"maxConcurrentPlayingAudios\":1},\"published_single_media_spacing\":{\"top_px\":3,\"right_px\":3,\"bottom_px\":3,\"left_px\":3},\"published_post_media_max_height_px\":280,\"post_media_right_edge_gesture_yield_percent\":{\"image\":7,\"video_surface\":7,\"video_seek\":7},\"new_post_text_area_height\":{\"viewport_height_ratio\":0.3,\"minimum_px\":180,\"if_viewpoint_to_tall_edit_area_height\":262,\"fallback_px\":262},\"post_editor_layout\":{\"keyboard_hidden_text_display_area_vertical_offset_px\":180,\"attachment_row_height\":48,\"keyboard_lift_animation_duration_ms\":220,\"keyboard_viewport_policy\":{\"keep_toolbar_and_media_rows_stable\":true,\"preserve_keyboard_state_on_tool_activation\":true,\"restore_keyboard_state_after_external_tool\":true}},\"cursor_drop_color\":\"#14A89A\",\"main_status_bar\":{\"main_status_bar_height\":52,\"main_status_bar_vertical_move\":-40,\"_main_status_bar_top_margin\":0,\"_main_status_bar_bottom_margin\":0,\"_main_status_bar_horizontal_margin\":8,\"_main_status_bar_text_font_size\":16,\"_main_status_bar_battery_icon_and_percentage_gap\":7,\"_main_status_bar_battery_icon_size\":30,\"_main_status_bar_battery_icon_horizontal_offset_px\":13,\"_main_status_bar_battery_percentage_horizontal_offset_px\":13,\"_main_status_bar_settings_button_hit_area_size\":44,\"_main_status_bar_settings_icon_size\":26,\"_main_status_bar_settings_button_horizontal_offset_px\":13,\"_main_status_bar_datetime_format_pattern\":\"HH:mm\",\"_main_status_bar_time_region_right_padding\":6,\"_main_status_bar_time_text_horizontal_offset_px\":0},\"viewer_media_scale\":{\"image_viewer_max_scale\":-1,\"video_viewer_max_scale\":-1},\"image_viewer_background_switch_configuration\":{\"background_color_cycle\":[\"#000000\",\"#FFFFFF\",\"#808080\"],\"default_background_color_index\":0}}"
    private const val SECTION_0 = "{\"global_set_background\":\"#AED194\",\"global_set_body\":\"#D2E9C2\",\"jet_scrollbar\":{\"visual_width_px\":7,\"interaction_width_px\":20}}"
    private const val SECTION_1 = "{\"load_animation\":{\"load_animation_background\":\"#AED194\",\"load_animation_minimum_duration_ms\":300},\"three_post_one_body\":{\"top_post\":{\"super_star\":{}},\"post_composer\":{},\"main_posts\":{\"interaction_timing\":{\"post_delete_reflow_animation_duration_ms\":320,\"post_reflow_animation\":{\"speed_or_duration\":\"speed\",\"star\":{\"duration_ms\":150,\"speed_px_per_second\":3600},\"cancel_star\":{\"duration_ms\":150,\"speed_px_per_second\":3600},\"super_star\":{\"duration_ms\":150,\"speed_px_per_second\":3600},\"cancel_super_star\":{\"duration_ms\":150,\"speed_px_per_second\":3600}},\"post_star_highlight\":{\"inset_width_px\":2,\"display_delay_after_reflow_ms\":300}},\"non_star\":{},\"star\":{}}},\"post_text_drawer_animation\":{\"duration_ms\":300},\"post_editor_text_caret\":{\"text_caret_visible_state_duration_ms\":750,\"text_caret_hidden_state_duration_ms\":750},\"shared_transition\":{\"duration_ms\":320}}"
    private const val SECTION_2 = "{\"three_post_one_body\":{\"surface_vertical_gap_px\":6,\"top_post\":{\"super_star\":{\"time_stamp_color\":\"999da2\",\"time_stamp_top_margin\":10,\"time_stamp_bottom_margin\":3}},\"main_posts\":{\"interaction_timing\":{\"post_horizontal_ellipsis_menu_dismiss_delay_ms\":100,\"delete_content_to_border_clear_delay_ms\":140,\"delete_border_clear_to_reflow_delay_ms\":140},\"non_star\":{\"time_stamp_color\":\"999da2\",\"time_stamp_top_margin\":3,\"time_stamp_bottom_margin\":3},\"star\":{\"time_stamp_color\":\"999da2\",\"time_stamp_top_margin\":3,\"time_stamp_bottom_margin\":3}}}}"
    private const val SECTION_3 = "{\"is_display\":{\"top_post\":true,\"post_composer\":true,\"main_posts\":true,\"star_post\":true}}"
    private const val SECTION_4 = "{\"three_post_one_body\":{\"top_post\":{\"super_star\":{\"border_rule\":{\"change_count\":0,\"sequence\":[{\"color\":\"#bfc1c4\",\"duration_ms\":1000}]}}},\"post_composer\":{\"border_rule\":{\"change_count\":0,\"sequence\":[{\"color\":\"#bfc1c4\",\"duration_ms\":1000}]}},\"main_posts\":{\"interaction_timing\":{\"post_star_highlight\":{\"normal\":{\"change_count\":0,\"sequence\":[{\"color\":\"#ffff00\",\"duration_ms\":500}]},\"super\":{\"change_count\":0,\"sequence\":[{\"color\":\"#ff0000\",\"duration_ms\":500}]}}},\"non_star\":{\"border_rule\":{\"change_count\":0,\"sequence\":[{\"color\":\"#bfc1c4\",\"duration_ms\":1000}]}},\"star\":{\"border_rule\":{\"change_count\":0,\"sequence\":[{\"color\":\"#bfc1c4\",\"duration_ms\":1000}]}}}}}"
    private const val SECTION_5 = "{\"post_attachment\":{\"audio_max_quantity\":1,\"video_max_quantity\":3,\"photo_max_quantity\":3,\"video_photo_coexistence\":true,\"video_photo_combined_max_quantity\":3},\"videoPlayback\":{\"maxConcurrentPlayingVideos\":3},\"audioPlayback\":{\"maxConcurrentPlayingAudios\":1},\"published_single_media_spacing\":{\"top_px\":3,\"right_px\":3,\"bottom_px\":3,\"left_px\":3},\"published_post_media_max_height_px\":280,\"post_media_right_edge_gesture_yield_percent\":{\"image\":7,\"video_surface\":7,\"video_seek\":7}}"
    private const val SECTION_6 = "{\"new_post_text_area_height\":{\"viewport_height_ratio\":0.3,\"minimum_px\":180,\"if_viewpoint_to_tall_edit_area_height\":262,\"fallback_px\":262},\"post_editor_layout\":{\"keyboard_hidden_text_display_area_vertical_offset_px\":180,\"attachment_row_height\":48,\"keyboard_lift_animation_duration_ms\":220,\"keyboard_viewport_policy\":{\"keep_toolbar_and_media_rows_stable\":true,\"preserve_keyboard_state_on_tool_activation\":true,\"restore_keyboard_state_after_external_tool\":true}},\"post_editor_text_caret\":{\"text_caret_width_px\":2,\"text_caret_color\":\"#14A89A\"},\"cursor_drop_color\":\"#14A89A\"}"
    private const val SECTION_7 = "{\"main_status_bar\":{\"main_status_bar_height\":52,\"main_status_bar_vertical_move\":-40,\"_main_status_bar_top_margin\":0,\"_main_status_bar_bottom_margin\":0,\"_main_status_bar_horizontal_margin\":8,\"_main_status_bar_text_font_size\":16,\"_main_status_bar_battery_icon_and_percentage_gap\":7,\"_main_status_bar_battery_icon_size\":30,\"_main_status_bar_battery_icon_horizontal_offset_px\":13,\"_main_status_bar_battery_percentage_horizontal_offset_px\":13,\"_main_status_bar_settings_button_hit_area_size\":44,\"_main_status_bar_settings_icon_size\":26,\"_main_status_bar_settings_button_horizontal_offset_px\":13,\"_main_status_bar_datetime_format_pattern\":\"HH:mm\",\"_main_status_bar_time_region_right_padding\":6,\"_main_status_bar_time_text_horizontal_offset_px\":0}}"
    private const val SECTION_8 = "{\"viewer_media_scale\":{\"image_viewer_max_scale\":-1,\"video_viewer_max_scale\":-1},\"image_viewer_background_switch_configuration\":{\"background_color_cycle\":[\"#000000\",\"#FFFFFF\",\"#808080\"],\"default_background_color_index\":0}}"

    fun parseObject(text: String): JSONObject = try {
        JSONObject(text)
    } catch (e: Exception) {
        throw IllegalArgumentException("Invalid hardcoded configuration", e)
    }

    fun requireObject(source: JSONObject, key: String): JSONObject = try {
        source.getJSONObject(key)
    } catch (e: Exception) {
        throw IllegalArgumentException("Missing hardcoded configuration object: $key", e)
    }

    fun requireString(source: JSONObject, key: String): String = try {
        source.getString(key)
    } catch (e: Exception) {
        throw IllegalArgumentException("Missing hardcoded config string: $key", e)
    }

    fun requireLong(source: JSONObject, key: String): Long = try {
        source.getLong(key)
    } catch (e: Exception) {
        throw IllegalArgumentException("Missing hardcoded config integer: $key", e)
    }

    fun readBundled(context: Context): String = HARDCODED
    fun readEffective(context: Context): String = ThemeStore.applyToConfig(context, HARDCODED)

    fun listBundledSectionsJson(context: Context): String =
        "[\"config.json\",\"anim.json\",\"home.json\",\"is_display.json\",\"jet_note_color_change_language.json\",\"media.json\",\"post_composer.json\",\"status_bar.json\",\"viewer.json\"]"

    fun readEffectiveSection(context: Context, section: String): String {
        val normalized = normalize(section)
        val raw = when (normalized) {
        "config.json" -> SECTION_0
        "anim.json" -> SECTION_1
        "home.json" -> SECTION_2
        "is_display.json" -> SECTION_3
        "jet_note_color_change_language.json" -> SECTION_4
        "media.json" -> SECTION_5
        "post_composer.json" -> SECTION_6
        "status_bar.json" -> SECTION_7
        "viewer.json" -> SECTION_8
        else -> throw IllegalArgumentException("Unknown hardcoded config section: $section")
        }
        return ThemeStore.applyToSection(context, normalized, raw)
    }

    fun readOverrideSection(context: Context, section: String): String {
        readEffectiveSection(context, section)
        return "{}"
    }

    fun saveRuntime(context: Context, json: String): Boolean = false
    fun saveRuntimeSection(context: Context, section: String, json: String): Boolean = false
    fun undoRuntime(context: Context): Boolean = false

    private fun normalize(section: String?): String {
        val name = section?.trim().orEmpty()
        return if (name.endsWith(".json")) name else "$name.json"
    }
}
