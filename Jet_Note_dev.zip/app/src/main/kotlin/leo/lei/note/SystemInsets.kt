package leo.lei.note

import android.os.Build
import android.view.View
import android.view.WindowInsets

internal object SystemInsets {
    data class Values(val top: Int, val bottom: Int, val imeBottom: Int, val imeVisible: Boolean)

    fun listen(view: View, block: (Values) -> Unit) {
        view.setOnApplyWindowInsetsListener { _, insets ->
            val top: Int
            val bottom: Int
            val imeBottom: Int
            val imeVisible: Boolean
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                val ime = insets.getInsets(WindowInsets.Type.ime())
                top = bars.top
                bottom = bars.bottom
                imeBottom = ime.bottom
                imeVisible = insets.isVisible(WindowInsets.Type.ime()) && ime.bottom > bars.bottom
            } else {
                @Suppress("DEPRECATION")
                top = insets.systemWindowInsetTop
                @Suppress("DEPRECATION")
                bottom = insets.systemWindowInsetBottom
                imeBottom = bottom
                imeVisible = false
            }
            block(Values(top, bottom, imeBottom, imeVisible))
            insets
        }
        if (view.isAttachedToWindow) view.requestApplyInsets()
        else view.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                v.removeOnAttachStateChangeListener(this)
                v.requestApplyInsets()
            }
            override fun onViewDetachedFromWindow(v: View) = Unit
        })
    }
}
