package leo.lei.note

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool

class UiSoundPlayer(context: Context) {
    enum class Cue { ARCHIVE, UNARCHIVE, STAR, SUPER_STAR, CANCEL_STAR, OPEN_TRASH, DELETE, EDITOR_OPEN, ERROR }
    private val pool = SoundPool.Builder().setMaxStreams(3).setAudioAttributes(
        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
    ).build()
    private val ids = mutableMapOf<Cue, Int>()
    private val ready = mutableSetOf<Int>()
    init {
        pool.setOnLoadCompleteListener { _, sampleId, status -> if (status == 0) ready += sampleId }
        fun load(c: Cue, res: Int) { ids[c] = pool.load(context.applicationContext, res, 1) }
        load(Cue.ARCHIVE, R.raw.ui_archive); load(Cue.UNARCHIVE, R.raw.ui_unarchive)
        load(Cue.STAR, R.raw.ui_star); load(Cue.SUPER_STAR, R.raw.ui_super_star)
        load(Cue.CANCEL_STAR, R.raw.ui_cancel_star_error_open_trash); load(Cue.OPEN_TRASH, R.raw.ui_cancel_star_error_open_trash)
        load(Cue.ERROR, R.raw.ui_cancel_star_error_open_trash); load(Cue.DELETE, R.raw.ui_delete_it)
        load(Cue.EDITOR_OPEN, R.raw.ui_editor_send)
    }
    fun play(cue: Cue) { ids[cue]?.takeIf { it in ready }?.let { pool.play(it, 0.30f, 0.30f, 1, 0, 1f) } }
    fun release() = pool.release()
}
