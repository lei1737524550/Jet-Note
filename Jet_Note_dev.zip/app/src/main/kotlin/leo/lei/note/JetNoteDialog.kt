package leo.lei.note

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import android.widget.TextView

object JetNoteDialog {
    data class Choice(val title: String, val subtitle: String = "", val destructive: Boolean = false)

    fun showChoices(
        activity: Activity,
        title: String,
        message: String,
        choices: List<Choice>,
        cancelText: String,
        onChoice: (Int) -> Unit,
        onCancel: () -> Unit
    ) {
        val theme = ThemeStore.current(activity)
        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCanceledOnTouchOutside(true)

        val dp: (Float) -> Int = { UiTokens.dp(activity, it) }
        val stroke = if (theme == ThemeStore.Theme.DARK) Color.rgb(82, 84, 91) else Color.rgb(208, 209, 215)
        val secondary = theme.foregroundColor

        val panel = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20f), dp(20f), dp(20f), dp(16f))
            background = GradientDrawable().apply {
                setColor(theme.bodyColor)
                setStroke(dp(1f), stroke)
                cornerRadius = dp(20f).toFloat()
            }
        }
        panel.addView(TextView(activity).apply {
            text = title
            textSize = 20f
            setTextColor(theme.foregroundColor)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(-1, -2))
        if (message.isNotBlank()) panel.addView(TextView(activity).apply {
            text = message
            textSize = 14f
            setTextColor(secondary)
            alpha = .68f
            setPadding(0, dp(6f), 0, dp(16f))
            setLineSpacing(0f, 1.08f)
        }, LinearLayout.LayoutParams(-1, -2))

        choices.forEachIndexed { index, choice ->
            val row = LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(58f)
                setPadding(dp(16f), dp(10f), dp(16f), dp(10f))
                background = GradientDrawable().apply {
                    setColor(theme.topColor)
                    setStroke(dp(1f), stroke)
                    cornerRadius = dp(UiTokens.RADIUS_CONTROL_DP).toFloat()
                }
                isClickable = true
                isFocusable = true
                setOnClickListener { dialog.dismiss(); onChoice(index) }
            }
            row.addView(TextView(activity).apply {
                text = choice.title
                textSize = 16f
                setTextColor(if (choice.destructive) Color.rgb(190, 55, 55) else theme.foregroundColor)
            })
            if (choice.subtitle.isNotBlank()) row.addView(TextView(activity).apply {
                text = choice.subtitle
                textSize = 12.5f
                setTextColor(secondary)
                alpha = .62f
                setPadding(0, dp(2f), 0, 0)
            })
            panel.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8f) })
        }

        val cancel = TextView(activity).apply {
            text = cancelText
            textSize = 15f
            setTextColor(theme.foregroundColor)
            gravity = Gravity.CENTER
            minimumHeight = dp(46f)
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                cornerRadius = dp(UiTokens.RADIUS_CONTROL_DP).toFloat()
            }
            isClickable = true
            setOnClickListener { dialog.cancel() }
        }
        panel.addView(cancel, LinearLayout.LayoutParams(-1, dp(46f)).apply { topMargin = dp(2f) })

        dialog.setContentView(panel)
        dialog.setOnCancelListener { onCancel() }
        dialog.setOnShowListener {
            dialog.window?.apply {
                setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                val width = (activity.resources.displayMetrics.widthPixels - dp(32f)).coerceAtMost(dp(440f))
                setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT)
                setDimAmount(.30f)
                addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                statusBarColor = theme.topColor
                navigationBarColor = theme.bodyColor
            }
        }
        dialog.show()
    }
}
