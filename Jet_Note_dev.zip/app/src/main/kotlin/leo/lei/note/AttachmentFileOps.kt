package leo.lei.note

import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.security.DigestInputStream
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.util.Locale

/** Stateless file primitives shared by attachment import, backup and media writes. */
internal object AttachmentFileOps {
    fun copy(input: InputStream, output: OutputStream): Long {
        val buffer = ByteArray(64 * 1024)
        var total = 0L
        while (true) {
            val read = input.read(buffer)
            if (read == -1) break
            output.write(buffer, 0, read)
            total += read
        }
        return total
    }

    @Throws(IOException::class)
    fun sha256Digest(): MessageDigest = try {
        MessageDigest.getInstance("SHA-256")
    } catch (e: NoSuchAlgorithmException) {
        throw IOException("SHA-256 unavailable", e)
    }

    @Throws(IOException::class)
    fun sha256(file: File): String {
        val digest = sha256Digest()
        DigestInputStream(FileInputStream(file), digest).use { input ->
            val buffer = ByteArray(64 * 1024)
            while (input.read(buffer) != -1) Unit
        }
        return hex(digest.digest())
    }

    fun isSafeFileName(name: String?): Boolean = name != null &&
        name.matches(Regex("[A-Za-z0-9_.-]{1,200}")) &&
        !name.contains("..") && !name.contains("/") && !name.contains("\\") &&
        name != "." && name != ".." && !name.contains("\u0000")

    fun hex(bytes: ByteArray): String = buildString(bytes.size * 2) {
        bytes.forEach { append(String.format(Locale.US, "%02x", it.toInt() and 0xff)) }
    }
}
