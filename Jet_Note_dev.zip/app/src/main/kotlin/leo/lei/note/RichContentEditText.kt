package leo.lei.note

import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.AttributeSet
import android.view.DragEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputConnectionWrapper
import android.view.inputmethod.InputContentInfo
import android.widget.EditText

internal class RichContentEditText : EditText {
    var onImageUri: ((Uri, (() -> Unit)?) -> Boolean)? = null
    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
        val base = super.onCreateInputConnection(outAttrs) ?: return null
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N_MR1) return base
        outAttrs.contentMimeTypes = arrayOf("image/*")
        return object : InputConnectionWrapper(base, false) {
            override fun commitContent(info: InputContentInfo, flags: Int, opts: Bundle?): Boolean {
                if (!info.description.hasMimeType("image/*")) return super.commitContent(info, flags, opts)
                var granted = false
                try {
                    if ((flags and INPUT_CONTENT_GRANT_READ_URI_PERMISSION) != 0) {
                        info.requestPermission(); granted = true
                    }
                    val release = if (granted) ({ try { info.releasePermission() } catch (_: Exception) {} }) else null
                    if (onImageUri?.invoke(info.contentUri, release) == true) return true
                    release?.invoke()
                } catch (_: Exception) {
                    if (granted) try { info.releasePermission() } catch (_: Exception) {}
                }
                return super.commitContent(info, flags, opts)
            }
        }
    }

    override fun onTextContextMenuItem(id: Int): Boolean {
        if (id == android.R.id.paste || id == android.R.id.pasteAsPlainText) {
            val clip = (context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager)?.primaryClip
            if (clip != null) {
                for (i in 0 until clip.itemCount) {
                    val uri = clip.getItemAt(i).uri ?: continue
                    val mime = context.contentResolver.getType(uri).orEmpty()
                    if (mime.startsWith("image/") && onImageUri?.invoke(uri, null) == true) return true
                }
            }
        }
        return super.onTextContextMenuItem(id)
    }

    override fun onDragEvent(event: DragEvent): Boolean {
        if (event.action == DragEvent.ACTION_DROP) {
            val clip = event.clipData
            for (i in 0 until clip.itemCount) {
                val uri = clip.getItemAt(i).uri ?: continue
                val mime = context.contentResolver.getType(uri).orEmpty()
                if (mime.startsWith("image/") && onImageUri?.invoke(uri, null) == true) return true
            }
        }
        return super.onDragEvent(event)
    }
}
