package leo.lei.note

import android.view.View
import android.view.ViewTreeObserver
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator

/** Single source of truth for native page enter/exit motion. */
object NativePageEnterAnimation {
    enum class ContentFrom { LEFT, RIGHT }
    const val DEFAULT_DURATION_MS = 200L

    private fun contentTarget(view: View, from: ContentFrom): Float {
        val width = view.rootView.width.toFloat().coerceAtLeast(view.width.toFloat()).coerceAtLeast(1f)
        return if (from == ContentFrom.RIGHT) width else -width
    }

    private fun barTarget(view: View): Float = -(view.height * 2f).coerceAtLeast(1f)

    fun reset(topBar: View, content: View) {
        topBar.animate().cancel(); content.animate().cancel()
        topBar.translationY = 0f; content.translationX = 0f
        topBar.alpha = 1f; content.alpha = 1f
    }

    fun play(topBar: View, content: View, contentFrom: ContentFrom, durationMs: Long = DEFAULT_DURATION_MS) {
        fun start() {
            topBar.animate().cancel(); content.animate().cancel()
            topBar.translationY = barTarget(topBar)
            content.translationX = contentTarget(content, contentFrom)
            val easing = DecelerateInterpolator()
            topBar.animate().translationY(0f).setDuration(durationMs).setInterpolator(easing).start()
            content.animate().translationX(0f).setDuration(durationMs).setInterpolator(easing).withEndAction {
                reset(topBar, content)
            }.start()
        }
        if (topBar.isLaidOut && content.isLaidOut && content.rootView.width > 0) start() else {
            content.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
                override fun onPreDraw(): Boolean {
                    content.viewTreeObserver.removeOnPreDrawListener(this)
                    start(); return true
                }
            })
        }
    }

    fun playExit(topBar: View, content: View, contentFrom: ContentFrom, durationMs: Long = DEFAULT_DURATION_MS, onEnd: () -> Unit) {
        topBar.animate().cancel(); content.animate().cancel()
        // Exit is the geometric inverse of enter: 0 -> the same off-screen origin.
        topBar.translationY = 0f; content.translationX = 0f
        val easing = AccelerateInterpolator()
        var ended = false
        fun complete() {
            if (ended) return
            ended = true
            reset(topBar, content)
            onEnd()
        }
        topBar.animate().translationY(barTarget(topBar)).setDuration(durationMs).setInterpolator(easing).start()
        content.animate().translationX(contentTarget(content, contentFrom)).setDuration(durationMs).setInterpolator(easing).withEndAction { complete() }.start()
        // A detached content view must never leave the Activity stuck in a closing state.
        content.postDelayed({ if (!ended && !content.isAttachedToWindow) complete() }, durationMs + 48L)
    }
}
