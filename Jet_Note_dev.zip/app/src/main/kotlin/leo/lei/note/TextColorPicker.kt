package leo.lei.note

import android.app.Activity
import android.app.Dialog
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import kotlin.math.roundToInt

internal class TextColorPicker(private val activity: Activity, private val onPicked: (String?) -> Unit) {
    private fun dp(v: Float) = (v * activity.resources.displayMetrics.density).roundToInt()
    private val common = intArrayOf(Color.BLACK, Color.WHITE, Color.RED, 0xFFFF9800.toInt(), 0xFFFFD600.toInt(), 0xFF00A651.toInt(), 0xFF2196F3.toInt(), 0xFF9C27B0.toInt())

    fun show(anchorBottomCssPx: Float = 0f, webViewTopPx: Int = 0, webViewScale: Float = 1f, currentColor: String? = null) {
        activity.currentFocus?.let { (activity.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(it.windowToken, 0) }
        val dialog = Dialog(activity)
        val root = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(18f), dp(24f), dp(18f), dp(24f)); setBackgroundColor(0xFFF7F7F7.toInt()) }
        val presets = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        fun chip(color: Int?, label: String? = null): View = TextView(activity).apply {
            text = label ?: ""; gravity = Gravity.CENTER; textSize = 12f; setTextColor(if (color == Color.BLACK) Color.WHITE else Color.BLACK)
            val selected = color?.let { String.format("#%06X", 0xFFFFFF and it) }?.equals(currentColor, true) == true || (color == null && currentColor == null)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color ?: 0xFFE7E7E7.toInt()); setStroke(dp(if (selected) 3f else 1f), if (selected) 0xFF2196F3.toInt() else 0xFFBDBDBD.toInt()) }
            setOnClickListener { dialog.dismiss(); onPicked(color?.let { String.format("#%06X", 0xFFFFFF and it) }) }
        }
        fun addPreset(view: View) {
            presets.addView(view, LinearLayout.LayoutParams(dp(48f), 0, 1f).apply {
                topMargin = dp(2f); bottomMargin = dp(2f)
            })
        }
        addPreset(chip(null, "默认"))
        common.drop(1).forEach { c -> addPreset(chip(c)) }
        root.addView(presets, LinearLayout.LayoutParams(dp(72f), ViewGroup.LayoutParams.MATCH_PARENT))

        val picker = HsvPickerView(activity)
        currentColor?.let { runCatching { Color.parseColor(it) }.getOrNull() }?.let { picker.setColor(it) }
        root.addView(picker, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { marginStart = dp(18f) })
        picker.onColorChanged = { c ->  }
        picker.onColorConfirmed = { c -> dialog.dismiss(); onPicked(String.format("#%06X", 0xFFFFFF and c)) }
        dialog.setContentView(root)
        dialog.setOnShowListener {
            dialog.window?.apply {
                setBackgroundDrawableResource(android.R.color.transparent)
                setGravity(Gravity.BOTTOM)
                val decor = activity.window.decorView
                val decorLocation = IntArray(2).also { decor.getLocationOnScreen(it) }
                val navBottom = if (android.os.Build.VERSION.SDK_INT >= 30) {
                    decor.rootWindowInsets?.getInsets(WindowInsets.Type.navigationBars())?.bottom ?: 0
                } else 0
                val usableBottom = decorLocation[1] + decor.height - navBottom
                val anchorScreen = webViewTopPx + (anchorBottomCssPx * webViewScale).roundToInt()
                val wanted = (usableBottom - anchorScreen).coerceAtLeast(dp(240f))
                setLayout(ViewGroup.LayoutParams.MATCH_PARENT, wanted)
            }
        }
        dialog.show()
    }

    private class HsvPickerView(context: android.content.Context) : View(context) {
        var onColorChanged: ((Int) -> Unit)? = null
        var onColorConfirmed: ((Int) -> Unit)? = null
        fun setColor(color: Int) { Color.colorToHSV(color, hsv); invalidate() }
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG); private val hsv = floatArrayOf(210f, .7f, .8f)
        private var hueTop = 0f; private var hueBottom = 0f; private var squareBottom = 0f
        override fun onDraw(c: Canvas) {
            super.onDraw(c); val pad=24f; val bar=34f; val gap=30f
            hueTop = height-bar-pad; hueBottom=height-pad; squareBottom=hueTop-gap
            val square = RectF(pad,pad,width-pad,squareBottom)
            val hueColor=Color.HSVToColor(floatArrayOf(hsv[0],1f,1f))
            paint.shader=LinearGradient(square.left,square.top,square.right,square.top,Color.WHITE,hueColor,Shader.TileMode.CLAMP); c.drawRect(square,paint)
            paint.shader=LinearGradient(square.left,square.top,square.left,square.bottom,Color.TRANSPARENT,Color.BLACK,Shader.TileMode.CLAMP); c.drawRect(square,paint); paint.shader=null
            val colors = intArrayOf(
                Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN,
                Color.BLUE, Color.MAGENTA, Color.RED
            )
            paint.shader = LinearGradient(
                pad, 0f, width - pad, 0f, colors, null as FloatArray?, Shader.TileMode.CLAMP
            ); c.drawRoundRect(RectF(pad,hueTop,width-pad,hueBottom),bar/2,bar/2,paint); paint.shader=null
            paint.style=Paint.Style.STROKE; paint.strokeWidth=5f; paint.color=Color.WHITE
            val sx=square.left+hsv[1]*square.width(); val sy=square.top+(1f-hsv[2])*square.height(); c.drawCircle(sx,sy,13f,paint)
            val hx=pad+(hsv[0]/360f)*(width-2*pad); c.drawCircle(hx,(hueTop+hueBottom)/2,12f,paint); paint.style=Paint.Style.FILL
            paint.color=Color.HSVToColor(hsv); c.drawRoundRect(RectF(width-150f, squareBottom+8f, width-pad, hueTop-8f),18f,18f,paint)
        }
        override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
            val pad=24f
            if(e.action==MotionEvent.ACTION_DOWN||e.action==MotionEvent.ACTION_MOVE){
                if(e.y>=hueTop){ hsv[0]=(((e.x-pad)/(width-2*pad)).coerceIn(0f,1f))*360f }
                else { hsv[1]=((e.x-pad)/(width-2*pad)).coerceIn(0f,1f); hsv[2]=(1f-(e.y-pad)/(squareBottom-pad)).coerceIn(0f,1f) }
                invalidate(); onColorChanged?.invoke(Color.HSVToColor(hsv)); return true
            }
            if(e.action==MotionEvent.ACTION_UP){ return true }
            return true
        }
    }
}
